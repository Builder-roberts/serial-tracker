// Serial Tracker - background script (Firefox: event page; Chrome: service worker via background-sw.js). Every change to stored data goes through this file.
// How checks keep requests to a minimum:
//   * no tabs, windows or focus changes: checks are background requests to pages of stories you track
//   * no request until a chapter is predicted; one request shortly after that time, then repeated requests at
//     increasing intervals if nothing has been posted
//   * a minimum gap between requests to the SAME site (one request at a time per site); different sites are checked side by side, so a
//     slow or rate-limited site never holds up the others. Retry-After and bot-check pages respected
//   * everything runs inside the browser (event page + alarms): no server, no account, nothing is sent anywhere but the sites you track
//   * a site's own feed (using ETag / If-Modified-Since) is asked first, because a "not modified" reply is smaller than a page
//   * a tracked page that you open yourself is read as a check, with no extra request (see content.js)
'use strict';
const api = typeof browser !== 'undefined' ? browser : chrome;
const { model: M, adapters: AD } = self.ST;
const MIN = 6e4, HOUR = 36e5, DAY = 864e5, PFX = 's:', AUTO_BATCH = 24, AUTO_PER_HOST = 4, MAX_LANES = 6, MAX_PAGES = 8;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const DASH = () => api.runtime.getURL('dashboard/dashboard.html');

// ---------------------------------------------------------------- running without a DOM (Chrome)
// Chrome's background is a service worker: no DOMParser, no blob addresses, and it is stopped after ~30 s without activity.
//   * Reading HTML/XML and making a file to download is done by a hidden offscreen page (offscreen/offscreen.html, same code
//     as lib/domops.js). Where a DOM exists (Firefox's event page) the same operations simply run here.
//   * While a check run, import or other long job is going, an extension API call every 20 s keeps the worker running.
const DO = self.ST.domops;
const IS_SW = typeof ServiceWorkerGlobalScope !== 'undefined' && self instanceof ServiceWorkerGlobalScope;
let offscreenReady = null;
function ensureOffscreen() {
  if (!offscreenReady) offscreenReady = (async () => {
    if (!api.offscreen) throw new Error('This browser has no offscreen documents, so pages cannot be read.');
    const have = api.runtime.getContexts ? await api.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] }) : [];
    if (have.length) return;
    try { await api.offscreen.createDocument({ url: 'offscreen/offscreen.html', reasons: ['DOM_PARSER'], justification: 'Read the HTML of the pages of stories you track.' }); }
    catch (e) { if (!/single offscreen|already exists/i.test(String((e && e.message) || e))) throw e; }   // another call made it first
  })().catch(e => { offscreenReady = null; throw e; });
  return offscreenReady;
}
async function domCall(op, args) {
  if (typeof DOMParser !== 'undefined') return DO.ops[op](args);                       // a page with a DOM: do it here
  for (let attempt = 0; ; attempt++) {
    await ensureOffscreen();
    let r = null;
    try { r = await api.runtime.sendMessage({ target: 'offscreen', op, args }); } catch (e) { r = null; }
    if (r && r.error) throw new Error(r.error);
    if (r && typeof r.json === 'string') return DO.dec(r.json);
    offscreenReady = null;                                                            // it was closed or didn't answer: make it again, once
    if (attempt) throw new Error('The page reader did not answer.');
  }
}
let awake = 0, awakeTimer = null;
function holdAwake() {                                                                // returns a function that lets go again
  if (!IS_SW) return () => {};
  if (++awake === 1) awakeTimer = setInterval(() => { try { api.runtime.getPlatformInfo().catch(() => {}); } catch (e) { /* worker is going away */ } }, 20000);
  let done = false;
  return () => { if (done) return; done = true; if (--awake === 0) { clearInterval(awakeTimer); awakeTimer = null; } };
}
// Opens the dashboard, or switches to it when it's already open in a tab.
async function openDashboard(storyId, filters) {
  const target = DASH() + (typeof storyId === 'string' && storyId ? '#story=' + encodeURIComponent(storyId) : filters ? '#filters' : '');       // the dashboard opens that story's details, or its filter panel
  try {
    const tabs = await api.tabs.query({}), tab = tabs.find(t => t.url && t.url.split('#')[0] === DASH());
    if (tab) {
      await api.tabs.update(tab.id, storyId || filters ? { active: true, url: target } : { active: true });
      if (api.windows && tab.windowId !== undefined) await api.windows.update(tab.windowId, { focused: true }).catch(() => {});
      return { ok: true, reused: true };
    }
  } catch (e) { /* fall through to opening a new one */ }
  await api.tabs.create({ url: target });
  return { ok: true, reused: false };
}

// ---------------------------------------------------------------- storage (one key per bookmark)
let chain = Promise.resolve();
const locked = fn => { const p = chain.then(() => fn()); chain = p.catch(() => {}); return p; };   // serialise read-modify-write

async function loadAll() {
  const all = await api.storage.local.get(null), recs = [];
  for (const k in all) if (k.startsWith(PFX)) recs.push(all[k]);
  const settings = Object.assign({}, M.DEFAULT_SETTINGS, all.settings); M.tune(settings);
  return { recs, settings, groups: all.groups || {} };
}
const getSettings = async () => { const s = Object.assign({}, M.DEFAULT_SETTINGS, (await api.storage.local.get('settings')).settings); M.tune(s); return s; };
const getRec = async id => (await api.storage.local.get(PFX + id))[PFX + id] || null;
const putRec = rec => api.storage.local.set({ [PFX + rec.id]: rec });
const mutate = (id, fn) => locked(async () => {
  const rec = await getRec(id); if (!rec) return null;
  const next = fn(rec); if (!next) return null;
  await putRec(next); return next;
});
const getGroups = async () => (await api.storage.local.get('groups')).groups || {};
const setGroups = g => api.storage.local.set({ groups: g });
const groupOfRec = (groups, id) => Object.values(groups).find(g => (g.members || []).includes(id)) || null;
// A group id ("g:...") stands for all its sources; a plain id is just itself.
const expandIds = (ids, groups) => [...new Set(ids.flatMap(id => (M.isGroupId(id) && groups[id.slice(2)]) ? groups[id.slice(2)].members : (M.isGroupId(id) ? [] : [id])))];
let runChain = Promise.resolve();                                                   // several sites are checked at once, so updates to the run status are queued
const setRun = patch => { const p = runChain.then(async () => { const cur = (await api.storage.local.get('run')).run || {}; await api.storage.local.set({ run: Object.assign({}, cur, patch) }); }); runChain = p.catch(() => {}); return p; };

// ---------------------------------------------------------------- rate-limited fetching
const hostLast = new Map(), permCache = new Map();
async function hostGate(host, gapMs) {
  const now = Date.now(), at = Math.max(now, (hostLast.get(host) || 0) + gapMs + Math.random() * 1500);
  hostLast.set(host, at);
  if (at > now) await sleep(at - now);
}
async function hasAccess(origin) {
  if (permCache.get(origin)) return true;
  try { const ok = await api.permissions.contains({ origins: [origin + '/*'] }); if (ok) permCache.set(origin, true); return ok; } catch (e) { return true; }
}
const fail = (kind, error, extra) => Object.assign({ ok: false, kind, error }, extra);

async function throttledFetch(url, headers, gapMs) {
  const u = new URL(url);
  if (!(await hasAccess(u.origin))) { const e = new Error('Needs access to ' + u.host); e.kind = 'permission'; throw e; }
  await hostGate(u.host, gapMs);
  const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 25000);
  try {
    // Uses the browser's own cookies, so existing logins and bot-check clearance apply. No headers are faked.
    const res = await fetch(url, { headers: headers || {}, credentials: 'include', redirect: 'follow', cache: 'no-cache', signal: ctl.signal });
    const text = res.status === 304 ? '' : await res.text();
    return { status: res.status, ok: res.ok, text, headers: res.headers, url: res.url || url, redirected: res.redirected };
  } finally { clearTimeout(timer); }
}

// Fallback for a bot check or login page: make the request from a tab you already have open on the same site. The request
// runs inside that page (same origin, cookies and container), so the site sees the same session as that tab.
// No tab is opened, moved or reloaded. Returns a response in the same shape as throttledFetch's, or null if there is no such tab.
async function fetchViaTab(url, gapMs) {
  try {
    const u = new URL(url), tabs = await api.tabs.query({ url: u.origin + '/*' });
    const tab = tabs.find(t => t.id !== undefined && !t.discarded && t.status === 'complete');
    if (!tab) return null;
    await hostGate(u.host, gapMs);
    const [r] = await api.scripting.executeScript({ target: { tabId: tab.id }, args: [url], func: async target => {
      try {
        const res = await fetch(target, { credentials: 'include', cache: 'no-cache' }), text = await res.text(), h = {};
        for (const k of ['cf-mitigated', 'etag', 'last-modified', 'retry-after']) { const v = res.headers.get(k); if (v !== null) h[k] = v; }
        return { status: res.status, text, url: res.url, redirected: res.redirected, h };
      } catch (e) { return { error: String(e) }; }
    } });
    const x = r && r.result;
    if (!x || x.error) return null;
    return { status: x.status, ok: x.status >= 200 && x.status < 300, text: x.text, url: x.url || url, redirected: !!x.redirected, headers: { get: k => (x.h && x.h[k.toLowerCase()]) || null } };
  } catch (e) { return null; }
}

// null if the response is usable, otherwise a failure outcome
function classify(res) {
  const head = res.text.slice(0, 6000);
  if (res.status === 429) {
    const ra = res.headers.get('retry-after'), n = Number(ra), ms = ra ? (isNaN(n) ? Math.max(0, Date.parse(ra) - Date.now()) : n * 1000) : 0;
    return fail('ratelimited', 'The site asked us to slow down (429).', { retryAfterMs: ms || 0 });
  }
  if (res.headers.get('cf-mitigated') === 'challenge' || /<title>\s*just a moment|challenge-platform|cf-chl-/i.test(head))
    return fail('blocked', 'The site’s bot check stopped the background check.');
  if (res.status === 403) return fail('blocked', 'The site refused the request (403).');
  if (res.status === 404 || res.status === 410) return fail('gone', 'The page is gone (' + res.status + '). The story may have been removed or moved.');
  if (res.redirected && /\/(login|signin|account\/login)\b/i.test(new URL(res.url).pathname)) return fail('login', 'The site wants you to log in to see this page.');
  if (!res.ok) return fail('http', 'The site answered with an error (' + res.status + ').');
  return null;
}

async function feedSignature(xml) {
  try { const items = await domCall('feedItems', { text: xml }); return items ? String(M.hash(items)) : null; } catch (e) { return null; }
}

// Fetches one page. If a bot check or login page blocks the plain request, retries from an already-open tab on that site. Returns { res } or { bad }.
async function fetchChecked(url, headers, gapMs) {
  let res = await throttledFetch(url, headers, gapMs);
  if (res.status === 304) return { res };
  let bad = classify(res);
  if (bad && (bad.kind === 'blocked' || bad.kind === 'login')) {
    const alt = await fetchViaTab(url, gapMs);
    if (alt && !classify(alt)) { res = alt; bad = null; }
  }
  return bad ? { bad: Object.assign({}, bad, { url }) } : { res };                  // the url is kept so the user can be sent to this exact page
}

// Asks the site's own feed whether anything changed (the cheapest check). Returns null when it can't tell; the caller then reads the page.
async function feedGate(rec, gapMs) {
  const st = rec.state || {}, headers = {};
  if (st.feedEtag) headers['If-None-Match'] = st.feedEtag;
  if (st.feedLastMod) headers['If-Modified-Since'] = st.feedLastMod;
  try {
    const res = await throttledFetch(rec.feedUrl, headers, gapMs);
    if (res.status === 304) return { changed: false, feed: { sig: st.feedSig, etag: st.feedEtag, lastMod: st.feedLastMod } };
    if (classify(res)) return null;
    const sig = await feedSignature(res.text), feed = { sig, etag: res.headers.get('etag'), lastMod: res.headers.get('last-modified') };
    return !sig || !st.feedSig ? { changed: true, feed } : { changed: sig !== st.feedSig, feed };
  } catch (e) { return null; }
}

// mode: 'initial' (first read; may follow several pages) | 'update' (routine check). manual = skip the shortcuts (feed check, conditional request).
// Never throws: returns an outcome object for M.applyOutcome.
async function fetchSeries(rec, s, { mode, manual }) {
  const ad = AD.get(rec.adapter), st = rec.state || {}, gapMs = s.hostGapSec * 1000, out = { ok: true, via: 'page', posts: null };
  try {
    if (!manual && s.useFeeds && rec.feedUrl && Date.now() - (st.lastFull || 0) < s.fullEveryDays * DAY) {
      const g = await feedGate(rec, gapMs);
      if (g) { out.feed = g.feed; if (g.changed === false) { out.via = 'feed'; return out; } }
    }
    const queue = ad.start(rec, mode).slice(), seen = new Set(), all = [], metas = [];
    let pages = 0, lastUrl = rec.url;
    const cap = ad.maxPages || MAX_PAGES, fstate = {}, fresh = [];
    while (queue.length && pages < cap) {
      const url = queue.shift(); if (seen.has(url)) continue; seen.add(url);
      const headers = {};
      if (pages === 0 && ad.conditional && mode === 'update' && !manual) {
        if (st.etag) headers['If-None-Match'] = st.etag;
        if (st.lastMod) headers['If-Modified-Since'] = st.lastMod;
      }
      lastUrl = url;
      const got = await fetchChecked(url, headers, gapMs);
      if (got.bad) {
        if (ad.optional && ad.optional(url, rec) && all.length) continue;                      // a source that only adds detail: skip it
        const alt = ad.fallback && ad.fallback(rec, url, got.bad);                                 // a source that can stand in for this one
        if (alt && !seen.has(alt)) { queue.unshift(alt); continue; }
        return got.bad;
      }
      const res = got.res;
      if (res.status === 304) return Object.assign(out, { posts: null });           // 304: the page has not changed
      if (pages === 0 && ad.conditional) out.validators = { etag: res.headers.get('etag') || null, lastMod: res.headers.get('last-modified') || null };
      const base = new URL(res.url || url);
      const parsed = ad.rawFor && ad.rawFor(url) ? ad.parseText(res.text, base, rec)                    // a JSON answer
        : await domCall('parse', { adapter: rec.adapter, text: res.text, mime: ad.mimeFor ? ad.mimeFor(url, res.text) : 'text/html', base: base.href, rec });
      pages++; all.push(...parsed.posts); metas.push(parsed.meta || {});
      if (pages === 1) { out.title = parsed.title; out.author = parsed.author; if (parsed.feedUrl) out.feedUrl = parsed.feedUrl; }
      if (ad.isFresh && ad.isFresh(parsed)) fresh.push(...parsed.posts.map(p => p.key));
      queue.push(...ad.follow(parsed, url, rec, mode, { fetched: pages, posts: all, deepPages: s.deepPages, keep: M.HISTORY_CAP, state: fstate }));
    }
    if (!all.length) return fail('layout', 'No chapter list found on the page. The site layout may have changed, or it needs you to be logged in.', { url: lastUrl });
    out.posts = [...new Map(all.map(p => [p.key, p])).values()];
    out.meta = Object.assign({}, ...metas);
    if (metas[0] && metas[0].desc !== undefined) out.meta.desc = metas[0].desc;
    if (ad.isFresh) out.fresh = fresh;                                             // only these can count as new chapters
    if (ad.finish) ad.finish(out.meta, { rec, mode, state: fstate });
    return out;
  } catch (e) {
    if (e.kind === 'permission') return fail('permission', e.message + '. Allow it from the dashboard.');
    return fail('network', e.name === 'AbortError' ? 'The site took too long to answer.' : 'Could not reach the site (' + (e.message || 'network error') + ').');
  }
}

async function storyOf(g) {                                                     // the combined record for one merged story, built from current storage
  const { recs } = await loadAll();
  return M.storyList(recs, { [g.id]: g })[0] || null;
}

// ---------------------------------------------------------------- the check queue
const queue = [];
let working = false, batch = { total: 0, done: 0, found: [], manual: false };
const hostOf = rec => { try { return new URL(rec.url).host; } catch (e) { return ''; } };

function enqueue(recs, manual) {
  for (const r of recs) {
    const ex = queue.find(q => q.id === r.id);
    if (ex) ex.manual = ex.manual || manual; else { queue.push({ id: r.id, host: hostOf(r), manual }); batch.total++; }
  }
  if (manual) batch.manual = true;
  if (!working) work().catch(e => console.error('Serial Tracker: check run failed', e));
}

async function work() {
  working = true;
  const s0 = await getSettings();
  await setRun({ running: true, total: batch.total, done: batch.done, current: null, manual: batch.manual, startedAt: Date.now() });
  await api.alarms.create('tick', { when: Date.now() + 10 * MIN });                // backup alarm in case this background page is unloaded during the run
  let offline = false;
  const active = new Map(), autoIds = [];                                           // host -> title being read right now; stories to open in a tab
  const showActive = () => { const t = [...active.values()]; return setRun({ current: t.length ? t.slice(0, 2).join(', ') + (t.length > 2 ? ' and ' + (t.length - 2) + ' more' : '') : null }); };
  async function checkOne(it) {                                                     // one story: read it, fold the result in, note anything new
    const rec = await getRec(it.id);
    if (rec) {
      active.set(it.host, rec.title); await showActive();
      const s = await getSettings(), out = await fetchSeries(rec, s, { mode: 'update', manual: it.manual });
      if (!out.ok && ['blocked', 'login', 'layout'].includes(out.kind) && (rec.autoOpen || s.autoOpenBlocked)) autoIds.push(it.id);     // read it in a tab, without asking
      const g0 = groupOfRec(await getGroups(), it.id), before = g0 ? await storyOf(g0) : null, grouped = !!(g0 && before && before.virtual);     // merged story: treated as one story
      let note = null;
      await mutate(it.id, r => {
        const now = Date.now(), eligible = grouped ? M.notifyEligible(before, now) : M.notifyEligible(r, now), x = M.applyOutcome(r, out, s, now);     // notification eligibility is decided from the state before this check
        note = { r, x, eligible }; return x.rec;
      });
      if (note) {
        let added = note.x.added, title = note.r.title, url = null, id = note.r.id;
        if (grouped) {                                                              // new = a chapter the story didn't have yet, from any source
          const after = await storyOf(g0), had = new Set(before.history.map(e => e.k));
          added = after.history.filter(e => !had.has(e.k)); title = after.title; id = after.id;
          url = added[0] ? (after.hrefs[added[0].k] || M.chapterHref(after, '') || after.home || null) : null;
        } else if (added[0]) url = M.chapterHref(note.r, added[0].k) || M.chapterHref(note.r, note.r.home) || null;
        batch.found.push({ id, title, added, eligible: note.eligible, url });
      }
    }
    batch.done++;
    active.delete(it.host);
    await setRun({ done: batch.done, total: batch.total }); await showActive();
  }
  // One lane per site: a lane reads its site's stories one after another (the per-site gap is enforced in hostGate), and up to MAX_LANES lanes
  // run side by side. So five sites take about as long as the slowest one, not the sum, and no site sees more than one request at a time.
  async function lane() {
    for (;;) {
      if (typeof navigator !== 'undefined' && navigator.onLine === false) { offline = true; return; }
      const busy = new Set(active.keys());
      const i = queue.findIndex(q => !busy.has(q.host) && !lanes.has(q.host));
      if (i < 0) return;
      const [it] = queue.splice(i, 1); lanes.add(it.host);
      try { while (it) {
        await checkOne(it);
        const j = queue.findIndex(q => q.host === it.host);                         // the same site's next story, if there is one
        if (j < 0 || (typeof navigator !== 'undefined' && navigator.onLine === false)) break;
        Object.assign(it, queue.splice(j, 1)[0]);
      } } catch (e) { console.error('Serial Tracker: check failed', e); } finally { lanes.delete(it.host); }
    }
  }
  const lanes = new Set(), letGo = holdAwake();
  try {
    while (queue.length && !offline) {
      const spare = MAX_LANES - lanes.size, starters = [];
      for (let k = 0; k < spare; k++) starters.push(lane());
      await Promise.all(starters);
      if (!lanes.size && queue.length && !offline) await sleep(500);                 // nothing could start: wait a moment, then look again
      while (lanes.size) await sleep(200);
    }
  } finally {
    letGo();
    const finished = batch; batch = { total: 0, done: 0, found: [], manual: false };
    queue.length = 0;                      // anything not checked (for example when offline) stays due and is checked at the next alarm
    await setRun({ running: false, current: null, finishedAt: Date.now(), total: finished.total, done: finished.done });
    if (autoIds.length) await autoVisit(autoIds).catch(e => console.error('Serial Tracker: could not open pages', e));
    working = false;
    await updateBadge();
    await reschedule(offline ? 5 * MIN : 90 * 1000);
    const items = finished.found.filter(f => f.added.length && f.eligible).map(f => ({ id: f.id, title: f.title, count: f.added.length, first: f.added[0].t, url: f.url }));
    if (!finished.manual && s0.notify) { if (items.length) await holdItems(items); await flushHeld(); }     // sent now, or held until quiet hours end
    if (queue.length && !working) work().catch(e => console.error('Serial Tracker: check run failed', e));   // more checks were queued while this run was finishing
  }
}

// ---------------------------------------------------------------- alarms
async function reschedule(minDelay) {
  const { recs, settings } = await loadAll();
  const times = settings.auto === 'off' ? [] : recs.filter(r => !r.paused && r.state && r.state.nextCheckAt).map(r => r.state.nextCheckAt);
  await api.alarms.clear('tick');
  if (!times.length) { await api.storage.local.set({ sched: { nextAt: null } }); return; }
  const when = Math.max(Math.min(...times), Date.now() + (minDelay == null ? 5000 : minDelay));
  await api.alarms.create('tick', { when });
  await api.storage.local.set({ sched: { nextAt: when } });
}

async function onTick() {
  await tidyVisit().catch(() => {});
  const { recs, settings } = await loadAll();
  if (settings.auto === 'off') return reschedule();
  const now = Date.now();
  const perHost = new Map(), due = recs.filter(r => !r.paused && r.state && r.state.nextCheckAt && r.state.nextCheckAt <= now)
    .sort((a, b) => a.state.nextCheckAt - b.state.nextCheckAt)
    .filter(r => { const h = hostOf(r), n = perHost.get(h) || 0; perHost.set(h, n + 1); return n < AUTO_PER_HOST; })   // after a long absence: at most AUTO_PER_HOST stories per site...
    .slice(0, AUTO_BATCH);                                                                                              // ...and AUTO_BATCH in all, so one big site can't crowd out the rest
  if (due.length) enqueue(due, false); else await reschedule();
}

async function recomputeAll() {
  const { recs, settings } = await loadAll(), now = Date.now();
  await locked(async () => {
    for (const r of recs) {
      const cur = await getRec(r.id); if (!cur) continue;
      const st = (cur.state = cur.state || {});
      const manualOnly = !!st.failures && !!M.analysisOf(cur) && M.breakPlan(cur, now) === null;      // a dormant story that failed: still only checked by hand
      st.nextCheckAt = cur.paused || settings.auto === 'off' || manualOnly ? null : (st.failures ? (st.nextCheckAt || now) : M.nextCheckAt(cur, settings, now));
      await putRec(cur);
    }
  });
}

// ---------------------------------------------------------------- badge + notifications
async function updateBadge() {
  const { recs, settings, groups } = await loadAll();
  const n = settings.badge ? M.badgeCount(M.storyList(recs, groups)) : 0;      // the badge counts unread chapters of favorites and of non-favorites under the unread limit; silenced stories are excluded
  try {
    await api.action.setBadgeText({ text: n ? (n > 99 ? '99+' : String(n)) : '' });
    if (n) {
      const bg = settings.colUnread || '#B3345A', c = parseInt(bg.slice(1), 16), lum = 0.299 * (c >> 16) + 0.587 * ((c >> 8) & 255) + 0.114 * (c & 255);
      await api.action.setBadgeBackgroundColor({ color: bg });
      if (api.action.setBadgeTextColor) await api.action.setBadgeTextColor({ color: lum > 150 ? '#000000' : '#FFFFFF' });
    }
  } catch (e) { /* badge is cosmetic */ }
}

// ---- quiet hours: notifications found during quiet hours are held and sent when quiet hours end, unless the story has been read by then
const inQuiet = (s, d) => {
  if (!s.quietOn || s.quietFrom === s.quietTo) return false;
  const h = (d || new Date()).getHours();
  return s.quietFrom < s.quietTo ? h >= s.quietFrom && h < s.quietTo : h >= s.quietFrom || h < s.quietTo;
};
const quietEnd = (s, now) => { const d = new Date(now); d.setHours(s.quietTo, 0, 5, 0); if (d.getTime() <= now) d.setDate(d.getDate() + 1); return d.getTime(); };
async function holdItems(items) {
  const held = (await api.storage.local.get('held')).held || [];
  for (const i of items) { const ex = held.find(h => h.id === i.id); if (ex) { ex.count += i.count; ex.url = i.url || ex.url; } else held.push(i); }
  await api.storage.local.set({ held });
}
async function flushHeld() {
  const s = await getSettings(), held = (await api.storage.local.get('held')).held || [];
  if (!held.length) return;
  if (inQuiet(s)) { await api.alarms.create('quiet', { when: quietEnd(s, Date.now()) }); return; }
  await api.alarms.clear('quiet'); await api.storage.local.remove('held');
  if (!s.notify) return;
  const { recs, groups } = await loadAll(), byId = new Map(M.storyList(recs, groups).map(r => [r.id, r]));
  const items = held.filter(i => { const r = byId.get(i.id); return r && !r.silenced && !r.ended && M.unreadOf(r) > 0; });
  if (items.length) await notifyNew(items);
}

// ---------------------------------------------------------------- automatic backup (optional; needs the Downloads permission)
async function ensureBackupAlarm() {
  const s = await getSettings();
  await api.alarms.clear('backup');
  if (s.autoBackup) await api.alarms.create('backup', { delayInMinutes: 2, periodInMinutes: 60 });
}
async function runBackup(force) {
  const s = await getSettings(), prev = (await api.storage.local.get('backup')).backup || {}, now = Date.now();
  if (!force && (!s.autoBackup || (prev.at && now - prev.at < s.backupDays * DAY - 30 * MIN))) return { ok: true, skipped: true };
  const note = x => api.storage.local.set({ backup: Object.assign({}, prev, x) });
  if (!api.downloads) { await note({ error: 'The Downloads permission hasn’t been allowed.', failedAt: now }); return { ok: false, error: 'The Downloads permission hasn’t been allowed.' }; }
  const { recs, groups } = await loadAll();
  const body = JSON.stringify({ app: 'serial-tracker', version: 1, exportedAt: new Date(now).toISOString(), settings: s, series: recs, groups }, null, 1);
  const url = typeof URL.createObjectURL === 'function' ? URL.createObjectURL(new Blob([body], { type: 'application/json' })) : await domCall('blobUrl', { body, type: 'application/json' });
  try {
    await api.downloads.download({ url, filename: 'Serial Tracker backups/serial-tracker-' + new Date(now).toISOString().slice(0, 10) + '.json', conflictAction: 'uniquify', saveAs: false });
    await note({ at: now, error: null, failedAt: null });
    return { ok: true };
  } catch (e) {
    await note({ error: String((e && e.message) || e), failedAt: now });
    return { ok: false, error: String((e && e.message) || e) };
  } finally { setTimeout(() => { if (typeof URL.revokeObjectURL === 'function' && typeof URL.createObjectURL === 'function') URL.revokeObjectURL(url); else domCall('revokeUrl', { url }).catch(() => {}); }, 60000); }
}

async function notifyNew(items) {
  try {
    if (!api.notifications || !(await api.permissions.contains({ permissions: ['notifications'] }))) return;
    const links = (await api.storage.local.get('notifLinks')).notifLinks || {}, icon = api.runtime.getURL('icons/128.png');
    const max = (await getSettings()).notifyMax, shown = items.length > max ? items.slice(0, max - 1) : items, rest = items.slice(shown.length);
    for (const i of shown) {                                                       // one notification per story; clicking it opens that story's new chapter
      const id = 'st-new:' + i.id;
      links[id] = i.url || DASH();
      await api.notifications.create(id, { type: 'basic', iconUrl: icon, title: i.title, message: i.count > 1 ? i.count + ' new chapters, starting with: ' + i.first : 'New: ' + i.first });
    }
    if (rest.length) {
      links['st-more'] = DASH();
      await api.notifications.create('st-more', { type: 'basic', iconUrl: icon, title: rest.length + ' more stories updated', message: rest.slice(0, 4).map(i => i.title + ' (+' + i.count + ')').join('\n') + (rest.length > 4 ? '\nand ' + (rest.length - 4) + ' more' : '') });
    }
    await api.storage.local.set({ notifLinks: links });
  } catch (e) { /* notifications are optional */ }
}
async function takeLink(id) {
  const links = (await api.storage.local.get('notifLinks')).notifLinks || {}, url = links[id];
  if (url !== undefined) { delete links[id]; await api.storage.local.set({ notifLinks: links }); }
  return url;
}
let notifWired = false;
function wireNotifications() {
  if (notifWired || !api.notifications || !api.notifications.onClicked) return;
  notifWired = true;
  api.notifications.onClicked.addListener(async id => {
    const url = await takeLink(id);
    if (url === undefined && !String(id).startsWith('st-')) return;
    if (url && /^https?:/.test(url)) api.tabs.create({ url }); else openDashboard();
    try { api.notifications.clear(id); } catch (e) { /* already gone */ }
  });
  if (api.notifications.onClosed) api.notifications.onClosed.addListener(id => { takeLink(id).catch(() => {}); });
}

// ---------------------------------------------------------------- page reads: register the content script only for sites of tracked stories
async function syncContentScripts() {
  if (!api.scripting || !api.scripting.registerContentScripts) return;
  try {
    const { recs } = await loadAll(), granted = [];
    for (const o of new Set(recs.map(r => { try { return new URL(r.url).origin + '/*'; } catch (e) { return null; } }).filter(Boolean))) {
      try { if (await api.permissions.contains({ origins: [o] })) granted.push(o); } catch (e) { /* skip */ }
    }
    const existing = await api.scripting.getRegisteredContentScripts({ ids: ['st-observer'] });
    if (!granted.length) { if (existing.length) await api.scripting.unregisterContentScripts({ ids: ['st-observer'] }); return; }
    const def = { id: 'st-observer', matches: granted, js: ['lib/adapters.js', 'content.js'], runAt: 'document_idle', persistAcrossSessions: true };
    if (existing.length) await api.scripting.updateContentScripts([def]); else await api.scripting.registerContentScripts([def]);
  } catch (e) { console.warn('Serial Tracker: could not update the page observer', e); }
}

// ---------------------------------------------------------------- reading blocked pages in a tab you can interact with
// For stories where a bot check or login page blocks background requests. The page opens in a normal tab so you can pass the
// check. Once it has loaded, content.js reads the chapter list from the page (as it does for any page you visit). The tab then
// closes if that setting is on, and the next blocked page opens. If you close a tab yourself, that page is skipped.
const getVisit = async () => { const v = (await api.storage.local.get('visit')).visit || {}; return { tabs: v.tabs || {}, queue: v.queue || [] }; };
const setVisit = v => api.storage.local.set({ visit: v });

// Queue entries are an id (opened for you, in front) or { id, auto: true } (opened by itself, in a background tab, always closed once read).
async function openNext(v) {                                                         // call inside locked()
  while (v.queue.length) {
    const q = v.queue.shift(), id = typeof q === 'string' ? q : q.id, auto = typeof q !== 'string', rec = await getRec(id);
    let url = rec && rec.state && rec.state.blockedUrl;
    try { if (url && new URL(url).origin !== new URL(rec.url).origin) url = rec.url; } catch (e) { url = null; }
    if (!url || !/^https?:/.test(url)) continue;                                      // no longer blocked, or no address to open: skip
    const tab = await api.tabs.create({ url, active: !auto });
    v.tabs[tab.id] = { id, at: Date.now(), auto };
    if (auto) api.alarms.create('visit', { when: Date.now() + AUTO_TAB_MS + 10000 });       // close it if it is still waiting then
    break;
  }
  await setVisit(v);
}
const openForCheck = ids => locked(async () => {
  const v = await getVisit();
  v.queue = [...new Set(ids)];
  await openNext(v);
  return { ok: true };
});
const visitDone = (tabId, recId) => locked(async () => {                             // the page was read: close the tab if that setting is on, then open the next page
  const v = await getVisit(), e = v.tabs[tabId];
  if (!e || e.id !== recId) return;
  delete v.tabs[tabId];
  if (e.auto || (await getSettings()).closeVisitTab) { try { await api.tabs.remove(tabId); } catch (err) { /* already gone */ } }
  await openNext(v);
});
// Pages that open by themselves: queued behind any page already open, one at a time. A tab that is gone (the browser restarted) or that has
// waited 3 minutes (a bot check that needs a click) is closed and skipped, so the queue can't get stuck; the usual button is still shown.
const AUTO_TAB_MS = 3 * MIN;
async function pruneVisit(v) {                                                       // call inside locked()
  const now = Date.now();
  for (const id of Object.keys(v.tabs)) {
    const e = v.tabs[id]; let alive = true;
    try { await api.tabs.get(Number(id)); } catch (err) { alive = false; }
    if (alive && e.auto && now - e.at > AUTO_TAB_MS) { try { await api.tabs.remove(Number(id)); } catch (err) { /* already gone */ } alive = false; }
    if (!alive || now - e.at > 6 * HOUR) delete v.tabs[id];
  }
}
const autoVisit = ids => locked(async () => {
  const v = await getVisit(); await pruneVisit(v);
  const have = new Set(v.queue.map(q => (typeof q === 'string' ? q : q.id)).concat(Object.values(v.tabs).map(e => e.id)));
  for (const id of ids) if (!have.has(id)) { v.queue.push({ id, auto: true }); have.add(id); }
  if (!Object.keys(v.tabs).length) await openNext(v); else await setVisit(v);
});
const tidyVisit = () => locked(async () => {                                         // run on every alarm: close auto tabs that waited too long, open the next page
  const v = await getVisit(); if (!Object.keys(v.tabs).length && !v.queue.length) return;
  const before = Object.keys(v.tabs).length; await pruneVisit(v);
  if (!Object.keys(v.tabs).length && (v.queue.length || before)) await openNext(v); else await setVisit(v);
});
if (api.tabs && api.tabs.onRemoved) api.tabs.onRemoved.addListener(tabId => locked(async () => {   // the tab was closed before the page was read: open the next page
  const v = await getVisit();
  if (!v.tabs[tabId]) return;
  delete v.tabs[tabId]; await openNext(v);
}));

// ---------------------------------------------------------------- actions
const uniqByKey = posts => [...new Map(posts.map(p => [p.key, p])).values()];

async function addSeries(d) {
  const idn = AD.identify(d.url);
  if (!idn) return { ok: false, error: 'This kind of page can’t be tracked.' };
  const filter = idn.filterable ? (d.filter || '').trim() : '', matcher = M.makeMatcher(filter);
  if (matcher.error) return { ok: false, error: matcher.error };
  const id = idn.key + (filter ? '#' + M.hash(filter.toLowerCase()).toString(36) : '');
  if (await getRec(id)) return { ok: false, error: 'Already tracked.', id };
  const s = await getSettings(), now = Date.now();
  let rec = M.newRecord({
    id, adapter: idn.adapter, kind: filter ? 'story' : idn.kind, title: (d.title || '').trim() || idn.hint || new URL(d.url).host,
    author: d.author || '', sourceUrl: idn.sourceUrl, homeUrl: idn.homeUrl, filter, favorite: d.favorite, feedUrl: d.feedUrl || '', generic: d.generic || null,
  }, now);
  let posts = Array.isArray(d.seedPosts) ? d.seedPosts : [], fetched = null;
  const m0 = d.meta || {}, newestElsewhere = idn.adapter === 'generic' && m0.pageCount > 1 && m0.desc === false;     // an oldest-first list split over pages: the newest chapters are on its last page
  if (!posts.length || newestElsewhere || idn.adapter === 'kemono' || idn.adapter === 'patreon' || idn.adapter === 'xenforo') {      // author feeds and long lists: also read the other pages to build the history
    fetched = await fetchSeries(rec, s, { mode: 'initial', manual: true });
    if (fetched.ok && fetched.posts) posts = uniqByKey([...fetched.posts, ...posts]);
    else if (!posts.length) {
      if (fetched.kind === 'blocked' || fetched.kind === 'login') {                  // keep the story; the first read completes when the page is opened in a tab
        rec = M.applyOutcome(rec, fetched, s, now).rec;
        await locked(() => putRec(rec));
        await Promise.all([syncContentScripts(), reschedule(), updateBadge()]);
        return { ok: true, id, needsVisit: true, kind: fetched.kind, error: fetched.error };
      }
      return { ok: false, kind: fetched.kind, error: fetched.error || 'Could not read the chapter list.' };
    }
  }
  if (!posts.length) return { ok: false, error: 'No chapter list found on this page.' };
  const ok = fetched && fetched.ok;
  rec.meta = (ok && fetched.meta) || d.meta || {};
  rec.feedUrl = d.feedUrl || (ok && fetched.feedUrl) || '';
  if (!d.author && ok && fetched.author) rec.author = fetched.author;
  if (!(d.title || '').trim() && ok && fetched.title) rec.title = fetched.title;
  rec = M.seed(rec, posts, s, now);
  if (AD.get(rec.adapter).stamp && rec.history.length) rec = M.setPlace(rec, rec.history[rec.history.length - 1], now);   // updates are all there is to follow: tracked from now on, so what exists is not unread
  await locked(() => putRec(rec));
  await Promise.all([syncContentScripts(), reschedule(), updateBadge()]);
  scanHistory([id]).catch(() => {});                                                // if history access is allowed, look up which chapter you had already reached
  return { ok: true, id, matched: rec.history.length };
}

// ---------------------------------------------------------------- stories made of several sources
const newGid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
// Links records (or whole merged stories) into one merged story. Returns the group id. A source can only be in one group.
async function linkSeries(ids, title) {
  ids = Array.isArray(ids) ? ids.filter(x => typeof x === 'string') : [];
  const groups = await getGroups(), want = [], seenG = [];
  for (const id of ids) {
    if (M.isGroupId(id)) { const g = groups[id.slice(2)]; if (g && !seenG.includes(g.id)) { seenG.push(g.id); want.push(...g.members); } }
    else { const g = groupOfRec(groups, id); if (g && !seenG.includes(g.id)) { seenG.push(g.id); want.push(...g.members); } else if (!g) want.push(id); }
  }
  const members = []; for (const id of new Set(want)) if (await getRec(id)) members.push(id);
  if (members.length < 2) return { ok: false, error: 'Pick two different stories to merge.' };
  const keep = seenG[0] ? groups[seenG[0]] : { id: newGid(), title: '', offsets: {} };
  seenG.slice(1).forEach(g => { keep.favorite = keep.favorite || groups[g].favorite; keep.silenced = keep.silenced || groups[g].silenced; delete groups[g]; });
  const recs = await Promise.all(members.map(getRec));
  keep.members = members; keep.offsets = keep.offsets || {};
  keep.title = (title || keep.title || '').trim() || recs[0].title;
  keep.favorite = !!keep.favorite || recs.some(r => r.favorite); keep.silenced = !!keep.silenced || recs.some(r => r.silenced);
  groups[keep.id] = keep;
  await setGroups(groups);
  await Promise.all([reschedule(), updateBadge()]);
  return { ok: true, id: M.GROUP_PREFIX + keep.id };
}
// Removes one source from its merged story. The story's favorite and silenced flags are copied to the removed source, and a story left with one source is dissolved.
async function unlinkSeries(id) {
  const groups = await getGroups(), g = groupOfRec(groups, id);
  if (!g) return { ok: true };
  const rest = g.members.filter(m => m !== id), leaving = [id];
  g.members = rest;
  if (rest.length < 2) { leaving.push(...rest); delete groups[g.id]; }
  for (const m of leaving) await mutate(m, r => Object.assign(r, { favorite: !!g.favorite, silenced: !!g.silenced, priority: !!g.priority }));
  if (g.offsets) delete g.offsets[id];
  await setGroups(groups); await Promise.all([reschedule(), updateBadge()]);
  return { ok: true };
}
async function updateGroup(gid, patch) {
  const groups = await getGroups(), g = groups[gid]; if (!g) return { ok: false, error: 'Not found.' };
  if (patch.title !== undefined) g.title = String(patch.title).trim() || g.title;
  ['favorite', 'silenced', 'priority'].forEach(k => { if (patch[k] !== undefined) g[k] = !!patch[k]; });
  if (patch.favorite === false) patch.priority = g.priority = false;
  if (patch.priority !== undefined) for (const m of g.members) await updateSeries(m, { priority: !!g.priority });
  if (patch.autoOpen !== undefined) for (const m of g.members) await updateSeries(m, { autoOpen: !!patch.autoOpen });
  if (patch.offsets && typeof patch.offsets === 'object') {
    g.offsets = g.offsets || {};
    for (const id in patch.offsets) if (g.members.includes(id) && Number.isFinite(Number(patch.offsets[id]))) g.offsets[id] = Math.max(-500, Math.min(500, Math.round(Number(patch.offsets[id]))));
  }
  if (patch.paused !== undefined) { g.paused = !!patch.paused; for (const m of g.members) await updateSeries(m, { paused: g.paused }); }
  if (patch.ended !== undefined) {
    g.ended = patch.ended === 'finished' || patch.ended === 'abandoned' ? patch.ended : undefined; g.paused = !!g.ended;
    for (const m of g.members) await updateSeries(m, { ended: g.ended || '' });
  }
  await setGroups(groups); await Promise.all([reschedule(), updateBadge()]);
  return { ok: true };
}

async function removeSeries(id) {
  const groups = await getGroups();
  if (M.isGroupId(id)) {                                                           // stop tracking a merged story: every source is removed
    const g = groups[id.slice(2)];
    if (g) { delete groups[g.id]; await setGroups(groups); for (const m of g.members) await locked(() => api.storage.local.remove(PFX + m)); }
    await Promise.all([syncContentScripts(), reschedule(), updateBadge()]);
    return { ok: true };
  }
  if (groupOfRec(groups, id)) await unlinkSeries(id);
  await locked(() => api.storage.local.remove(PFX + id));
  await Promise.all([syncContentScripts(), reschedule(), updateBadge()]);
  return { ok: true };
}

async function updateSeries(id, patch) {
  const s = await getSettings();
  if (patch.filter !== undefined) {                                                  // changing the filter changes which posts count: re-read
    const cur = await getRec(id); if (!cur) return { ok: false, error: 'Not found.' };
    const filter = String(patch.filter).trim(), m = M.makeMatcher(filter);
    if (m.error) return { ok: false, error: m.error };
    if (filter !== cur.filter) {
      const probe = Object.assign(M.clone(cur), { filter, history: [] }), out = await fetchSeries(probe, s, { mode: 'initial', manual: true });
      if (!out.ok || !out.posts) return { ok: false, error: out.error || 'Could not re-read the page.' };
      const rebuilt = M.seed(probe, out.posts, s, Date.now());
      await mutate(id, r => { const sn = new Map(r.history.filter(e => e.sn).map(e => [e.k, e.sn]));        // keep when each chapter was first seen
        return Object.assign(r, { filter, history: rebuilt.history.map(e => (sn.has(e.k) ? Object.assign(e, { sn: sn.get(e.k) }) : e)), unread: 0, readLate: null, lastNew: null, state: Object.assign(r.state || {}, rebuilt.state) }); });
    }
  }
  await mutate(id, r => {
    ['title', 'favorite', 'silenced', 'paused', 'priority', 'autoOpen', 'feedUrl'].forEach(k => { if (patch[k] !== undefined) r[k] = k === 'title' || k === 'feedUrl' ? String(patch[k]).trim() : !!patch[k]; });
    if (patch.favorite === false) r.priority = false;                                // "check more often" only applies to favorites
    if (patch.ended !== undefined) {                                                 // finished / abandoned: set by you; checking stops
      if (patch.ended === 'finished' || patch.ended === 'abandoned') { r.ended = patch.ended; r.paused = true; } else { delete r.ended; r.paused = false; }
    }
    if (patch.feedUrl !== undefined) Object.assign(r.state, { feedEtag: null, feedLastMod: null, feedSig: null });
    if (patch.paused !== undefined || patch.ended !== undefined || patch.feedUrl !== undefined) r.state.nextCheckAt = r.paused || s.auto === 'off' ? null : (r.state.nextCheckAt || M.nextCheckAt(r, s, Date.now()));
    if ((patch.priority !== undefined || patch.favorite === false) && !r.paused && !r.state.failures) r.state.nextCheckAt = M.nextCheckAt(r, s, Date.now());
    return r;
  });
  if (patch.autoOpen === true) { const r = await getRec(id); if (r && r.state && r.state.blockedUrl && !r.paused) await autoVisit([id]); }     // already stuck: open it now
  await Promise.all([reschedule(), updateBadge()]);
  return { ok: true };
}

async function markSeen(id) {
  const { recs } = await loadAll();
  const groups = await getGroups(), only = id === 'all' ? null : expandIds([id], groups);
  for (const r of recs) if ((id === 'all' || only.includes(r.id)) && !r.read && r.unread) await mutate(r.id, x => Object.assign(x, { unread: 0 }));   // only when the reading position is unknown
  await updateBadge();
  return { ok: true };
}

async function setSettings(patch) {
  patch = patch && typeof patch === 'object' ? patch : {};
  const next = await locked(async () => {
    const cur = await getSettings(), n = Object.assign({}, cur);
    for (const k in M.DEFAULT_SETTINGS) if (patch[k] !== undefined && typeof patch[k] === typeof M.DEFAULT_SETTINGS[k]) n[k] = patch[k];
    n.hostGapSec = Math.min(60, Math.max(3, n.hostGapSec));
    n.deepPages = Math.min(10, Math.max(1, Math.round(n.deepPages)));
    M.sanitizeDisplay(n);
    await api.storage.local.set({ settings: n });
    return n;
  });
  await recomputeAll(); await Promise.all([reschedule(), updateBadge(), ensureBackupAlarm(), flushHeld()]);
  return { ok: true, settings: next };
}

// Display settings only (theme, colors, Up next length). They do not affect the check schedule, so schedules are not recalculated.
const DISPLAY_KEYS = ['upNextPopup', 'upNextDash', 'theme', 'background', 'bgColor', 'density', 'groupHeadings', 'showByline', 'showLatest', 'showMeter', 'recentHours', 'stoppedUnread', 'badgeMaxUnread', 'notifyMax'].concat(M.COLOR_KEYS);
async function setDisplay(patch) {
  patch = patch && typeof patch === 'object' ? patch : {};
  const next = await locked(async () => {
    const n = Object.assign({}, await getSettings());
    DISPLAY_KEYS.forEach(k => { if (patch[k] !== undefined) n[k] = patch[k]; });
    M.sanitizeDisplay(n);
    await api.storage.local.set({ settings: n });
    return n;
  });
  await updateBadge();
  return { ok: true, settings: next };
}

async function importData(data) {
  if (data && !Array.isArray(data.series) && data.settings && typeof data.settings === 'object') {       // settings-only file
    await setSettings(data.settings);
    await Promise.all([syncContentScripts(), reschedule(), updateBadge()]);
    return { ok: true, imported: 0, existing: 0, invalid: 0 };
  }
  if (!data || !Array.isArray(data.series)) return { ok: false, error: 'That file isn’t a Serial Tracker backup.' };
  const now = Date.now(); let imported = 0, existing = 0, invalid = 0;
  await locked(async () => {
    for (const r of data.series) {
      const sane = r && typeof r.id === 'string' && r.id.length < 400 && typeof r.url === 'string' && /^https?:/.test(r.url) && Array.isArray(r.history) && typeof r.title === 'string';
      if (!sane) { invalid++; continue; }
      if (await getRec(r.id)) { existing++; continue; }                              // never overwrite what you already track
      r.history = r.history.filter(e => e && typeof e.k === 'string' && Number.isFinite(e.ts)).slice(-M.HISTORY_CAP);
      r.favorite = !!r.favorite; r.silenced = !!r.silenced; r.paused = !!r.paused; r.autoOpen = !!r.autoOpen; r.priority = !!r.priority && r.favorite;
      if (r.ended !== 'finished' && r.ended !== 'abandoned') delete r.ended; else r.paused = true;
      r.state = Object.assign({}, r.state, { failures: 0 });
      const due = M.nextCheckAt(r, await getSettings(), now);                          // from its own prediction: never earlier; one that is already due is spread over a few minutes
      r.state.nextCheckAt = due === null ? null : (due <= now ? now + 60000 + Math.random() * 600000 : due);
      await putRec(r); imported++;
    }
  });
  if (data.groups && typeof data.groups === 'object') {
    const groups = await getGroups(), { recs } = await loadAll(), have = new Set(recs.map(r => r.id)), taken = new Set(Object.values(groups).flatMap(g => g.members));
    for (const g of Object.values(data.groups)) {
      if (!g || typeof g.id !== 'string' || groups[g.id] || !Array.isArray(g.members)) continue;
      const members = g.members.filter(id => typeof id === 'string' && have.has(id) && !taken.has(id));
      if (members.length < 2) continue;
      members.forEach(id => taken.add(id));
      groups[g.id] = { id: g.id, title: String(g.title || '').slice(0, 140), members, favorite: !!g.favorite, silenced: !!g.silenced, priority: !!g.priority && !!g.favorite, ended: g.ended === 'finished' || g.ended === 'abandoned' ? g.ended : undefined, paused: !!g.paused, offsets: g.offsets && typeof g.offsets === 'object' ? g.offsets : {} };
    }
    await setGroups(groups);
  }
  if (data.settings && typeof data.settings === 'object') await setSettings(data.settings);
  await Promise.all([syncContentScripts(), reschedule(), updateBadge()]);
  return { ok: true, imported, existing, invalid };
}

// ---------------------------------------------------------------- import from a site: read a follows / watched list, then add the stories you choose
// scanList reads the list's pages (one page per host gap, the same spacing as other requests); importBatch adds the chosen stories one at a time.
// The queue is stored under 'bulk' so it survives the background page being unloaded; an alarm resumes it.
const MAX_LIST_PAGES = 15, LIST_ADAPTERS = ['xenforo', 'royalroad', 'scribblehub', 'patreon'];
const setScan = scan => api.storage.local.set({ scan });
const sameOrigin = (a, b) => { try { return new URL(a).origin === new URL(b).origin; } catch (e) { return false; } };

// A forum's watched-threads page lists only threads with unread posts unless it is asked for all of them (?unread=0), which would
// quietly leave most of the list out of an import. So an import always asks for all of them (an address that already says otherwise is kept).
const allWatched = href => { try { const u = new URL(href); if (/\/watched\/threads\/?$/.test(u.pathname) && !u.searchParams.has('unread')) { u.searchParams.set('unread', '0'); return u.href; } } catch (e) { /* not an address */ } return href; };

async function scanList(m) {
  let first; try { first = new URL(m.url); if (!/^https?:$/.test(first.protocol)) throw new Error(); } catch (e) { return { ok: false, error: 'That isn’t a web address.' }; }
  const wanted = allWatched(first.href); let fallbackSeed = null;
  if (wanted !== first.href) { first = new URL(wanted); if (m.seed) { fallbackSeed = m.seed; m = Object.assign({}, m, { seed: null }); } }    // the page you had shows only unread threads: read the full list instead
  const s = await getSettings(), gap = s.hostGapSec * 1000, items = [], keys = new Set();
  let label = '', curated = true, pages = 0, next = null, partial = '';
  const take = list => { for (const it of list || []) {
    const idn = it && typeof it.url === 'string' && AD.identify(it.url);
    if (!idn || !LIST_ADAPTERS.includes(idn.adapter) || keys.has(idn.key)) continue;
    keys.add(idn.key);
    items.push({ url: idn.homeUrl, key: idn.key, adapter: idn.adapter, title: String(it.title || '').slice(0, 140) || idn.hint || idn.homeUrl, author: String(it.author || '').slice(0, 80) });
  } };
  const seed = m.seed && Array.isArray(m.seed.items) ? m.seed : null;
  if (seed) { take(seed.items); label = String(seed.label || ''); curated = seed.curated !== false; pages = 1; next = seed.next && sameOrigin(seed.next, first.href) ? seed.next : null; }    // page 1 came from the page you had open
  else next = first.href;
  await setScan({ running: true, label, pages, found: items.length, url: first.href });
  try {
    while (next && pages < MAX_LIST_PAGES) {
      let got;
      try { got = await fetchChecked(next, {}, gap); } catch (e) {
        if (e.kind === 'permission') return { ok: false, kind: 'permission', origin: first.origin, error: 'Needs access to ' + first.host + '.' };
        if (pages) { partial = 'Stopped after ' + pages + ' page' + (pages === 1 ? '' : 's') + ': the site didn’t answer.'; break; }
        return { ok: false, error: 'Could not reach the site (' + ((e && e.message) || 'network error') + ').' };
      }
      if (got.bad && !pages && fallbackSeed) {                                          // the full list can't be read here: use the page you had, and say so
        const fs = fallbackSeed; fallbackSeed = null; take(fs.items); label = String(fs.label || ''); curated = fs.curated !== false; pages = 1;
        next = fs.next && sameOrigin(fs.next, first.href) ? fs.next : null; partial = 'Only the threads with unread posts are listed: the full watched list couldn’t be read (' + got.bad.error + ')';
        continue;
      }
      if (got.bad) {
        if (pages) { partial = 'Stopped after ' + pages + ' page' + (pages === 1 ? '' : 's') + ': ' + got.bad.error; break; }
        const needsYou = got.bad.kind === 'blocked' || got.bad.kind === 'login';
        return { ok: false, kind: got.bad.kind, needsYou, error: needsYou ? 'It can’t be read in the background (the site wants you logged in, or a bot check is in the way).' : got.bad.error };
      }
      const res = got.res, parsed = await domCall('parseList', { text: res.text, url: res.url || next });
      if (!parsed) { if (pages) break; return { ok: false, error: 'That page doesn’t look like a list of stories I can read.' }; }
      const before = items.length;
      take(parsed.items); pages++;
      if (!label) { label = parsed.label; curated = parsed.curated; }
      next = parsed.next && items.length > before && sameOrigin(parsed.next, first.href) ? allWatched(parsed.next) : null;    // stop when a page adds no new stories
      await setScan({ running: true, label, pages, found: items.length, url: first.href });
    }
  } finally { await setScan({ running: false }); }
  return { ok: true, label, curated, items, pages, more: !!next, partial };
}

const bulkMutate = fn => locked(async () => {
  const b = (await api.storage.local.get('bulk')).bulk; if (!b) return null;
  const n = fn(b); if (!n) return null;
  await api.storage.local.set({ bulk: n }); return n;
});
let bulkRunning = false;

async function importBatch(m) {
  const cur = (await api.storage.local.get('bulk')).bulk;
  if (cur && cur.running) return { ok: false, error: 'An import is already running.' };
  const { recs } = await loadAll(), have = new Set(recs.map(r => r.id.split('#')[0])), list = [], seen = new Set();
  for (const it of (Array.isArray(m.items) ? m.items : []).slice(0, 500)) {
    const idn = it && typeof it.url === 'string' && AD.identify(it.url);
    if (!idn || !LIST_ADAPTERS.includes(idn.adapter) || have.has(idn.key) || seen.has(idn.key)) continue;
    seen.add(idn.key); list.push({ url: idn.homeUrl, title: String(it.title || '').slice(0, 140), author: String(it.author || '').slice(0, 80) });
  }
  if (!list.length) return { ok: false, error: 'Everything chosen is already tracked.' };
  await api.storage.local.set({ bulk: { running: true, paused: false, total: list.length, done: 0, added: 0, existing: 0, visit: 0, empty: [], failed: [], queue: list, favorite: !!m.favorite, caughtUp: !!m.caughtUp, current: null, startedAt: Date.now() } });
  runBulk().catch(e => console.error('Serial Tracker: import failed', e));
  return { ok: true, total: list.length };
}

async function runBulk() {
  if (bulkRunning) return;
  bulkRunning = true;
  const letGo = holdAwake();
  try {
    await api.alarms.create('bulk', { delayInMinutes: 1, periodInMinutes: 1 });                // backup alarm in case this page is unloaded during the import
    for (;;) {
      const b = (await api.storage.local.get('bulk')).bulk;
      if (!b || !b.running || !b.queue.length) break;
      const it = b.queue[0];
      await bulkMutate(x => (x.running ? Object.assign(x, { current: it.title }) : null));
      let res; try { res = await addSeries({ url: it.url, title: it.title, author: it.author, favorite: b.favorite }); } catch (e) { res = { ok: false, error: String((e && e.message) || e) }; }
      if (res.ok && res.id && b.caughtUp && !res.needsVisit) await mutate(res.id, r => (r.history.length ? M.setPlace(r, r.history[r.history.length - 1], Date.now()) : null));
      const slow = !res.ok && res.kind === 'ratelimited';
      await bulkMutate(x => {
        if (!x.running) return null;                                                          // cancelled while this one was being read
        if (slow) { x.running = false; x.paused = true; x.current = null; return x; }          // keep the rest queued; the user resumes manually
        x.queue.shift(); x.done++;
        if (res.ok) { x.added++; if (res.needsVisit) x.visit++; }
        else if (/Already tracked/.test(res.error || '')) x.existing++;
        else if (res.kind === 'layout') { if (x.empty.length < 60) x.empty.push(it.title); }
        else if (x.failed.length < 60) x.failed.push({ title: it.title, error: res.error || 'Could not be added.' });
        if (!x.queue.length) { x.running = false; x.current = null; x.finishedAt = Date.now(); }
        return x;
      });
    }
  } finally {
    letGo();
    bulkRunning = false;
    const b = (await api.storage.local.get('bulk')).bulk;
    if (!b || !b.running) await api.alarms.clear('bulk');
  }
}
async function resumeBulk() {
  const b = (await api.storage.local.get('bulk')).bulk;
  if (b && b.running && b.queue.length) runBulk().catch(e => console.error('Serial Tracker: import failed', e));
}
const bulkStop = () => bulkMutate(x => Object.assign(x, { running: false, paused: false, cancelled: true, queue: [], current: null, finishedAt: Date.now() })).then(() => ({ ok: true }));
const bulkResume = async () => { await bulkMutate(x => (x.queue.length ? Object.assign(x, { running: true, paused: false }) : null)); resumeBulk(); return { ok: true }; };

// ---------------------------------------------------------------- reading position
// content.js asks about every page it loads on a tracked site. For list pages it reads the list; for chapter pages it records which chapter you are on.
async function onPage(url) {
  const idn = AD.identify(url), lists = [], reads = [];
  if (!idn) return { lists, reads };
  const { recs } = await loadAll(), source = AD.isSourcePage(url);
  for (const r of recs) {
    const same = r.adapter === idn.adapter && r.id.split('#')[0] === idn.key;
    if (same && source) { lists.push({ id: r.id, adapter: r.adapter, generic: r.generic, filter: r.filter }); continue; }
    if (same && r.adapter === 'xenforo') { reads.push({ id: r.id, mode: 'scroll' }); continue; }     // thread pages: position comes from scrolling
    const c = M.chapterForUrl(r, url, !same);                                                       // chapter pages: the address says which
    if (c.entry || (same && c.match)) reads.push({ id: r.id, mode: 'exact' });                      // ids are only matched within the story the address belongs to
  }
  return { lists, reads };
}

async function onRead(m) {
  const rec = await getRec(m.id); if (!rec) return { ok: false };
  const now = Date.now();
  let e = null, match = null;
  if (m.T !== undefined) {                                                          // XenForo: the date of the furthest post reached
    const idn = AD.identify(m.url);
    if (rec.adapter === 'xenforo' && idn && idn.key === rec.id.split('#')[0] && Number.isFinite(m.T) && m.T > 9.4e11 && m.T < now + DAY) e = M.chapterAtOrBefore(rec.history, m.T);
  } else {
    const c = M.chapterForUrl(rec, m.url), idn = AD.identify(m.url);
    e = c.entry;
    match = idn && idn.adapter === rec.adapter && idn.key === rec.id.split('#')[0] ? c.match : null;   // pending only for the story the address belongs to
  }
  if (e) await mutate(m.id, r => M.applyRead(r, e, 'page', now) || M.noteOpened(r, e, now));   // further than your place: move it. Earlier: remember it, so you can be offered to move your place back
  else if (match) await mutate(m.id, r => M.notePending(r, match, now));               // opened before we'd heard of it: resolved on the next read of the list
  await updateBadge();
  return { ok: true };
}

async function setPlaceFor(m) {
  const groups = await getGroups(), g = M.isGroupId(m.id) ? groups[m.id.slice(2)] : null;
  if (g) {                                                                         // merged story: every source that has that chapter is set to it; other sources are set to their nearest earlier chapter
    const story = await storyOf(g); if (!story) return { ok: false, error: 'Not found.' };
    const ch = m.k === 'latest' ? story.history[story.history.length - 1] : story.history.find(p => p.k === m.k);
    if (!ch) return { ok: false, error: 'That chapter isn’t in the list.' };
    const { recs } = await loadAll(), now = Date.now(), ms = recs.filter(x => g.members.includes(x.id)), c = M.mergeChapters(ms, g.offsets).find(x => x.k === ch.k);
    for (const r of ms) {
      const e = (c && c.srcs[r.id]) || M.chapterAtOrBefore(r.history, ch.ts);
      if (e) await mutate(r.id, x => M.setPlace(x, e, now));
    }
    await updateBadge(); return { ok: true };
  }
  const rec = await getRec(m.id); if (!rec) return { ok: false, error: 'Not found.' };
  const h = rec.history, e = m.k === 'latest' ? h[h.length - 1] : h.find(p => p.k === m.k);
  if (!e) return { ok: false, error: 'That chapter isn’t in the list.' };
  await mutate(m.id, r => M.setPlace(r, e, Date.now()));
  await updateBadge();
  return { ok: true };
}

// "Keep my place": drop the offer to move your place back to a chapter you re-opened.
async function keepPlaceFor(m) {
  const groups = await getGroups();
  for (const id of expandIds([m.id], groups)) await mutate(id, r => (r.lastOpened ? Object.assign(r, { lastOpened: null }) : null));
  return { ok: true };
}

// Browsing history is an optional permission. It is used to find where you stopped in stories you were reading before you tracked them.
const hasHistory = async () => !!api.history && !!(await api.permissions.contains({ permissions: ['history'] }).catch(() => false));
const furthest = es => es.reduce((b, e) => (!b || e.ts > b.ts ? e : b), null);

async function historyPlace(rec, s) {                                               // -> { entry, approx } or null
  const h = rec.history; if (!h.length) return null;
  if (rec.adapter === 'royalroad' || rec.adapter === 'scribblehub' || rec.adapter === 'patreon' || rec.adapter === 'kemono') {   // the address names the chapter: exact
    const text = rec.adapter === 'royalroad' ? '/fiction/' + rec.id.split(':')[1] : rec.adapter === 'scribblehub' ? '/read/' + rec.id.split('#')[0].split(':')[1] + '-' : rec.adapter === 'patreon' ? 'patreon.com/posts/' : new URL(rec.url).pathname + '/post/';
    const items = await api.history.search({ text, startTime: 0, maxResults: 5000 });  // (startTime defaults to "last 24 hours")
    const e = furthest(items.map(it => M.chapterForUrl(rec, it.url).entry).filter(Boolean));
    return e ? { entry: e, approx: false } : null;
  }
  if (rec.adapter === 'xenforo') {
    const items = await api.history.search({ text: new URL(rec.home).pathname, startTime: 0, maxResults: 5000 });
    const exact = items.map(it => {                                                 // a visit to a specific post (permalink / #post-123)
      const m = it.url.match(/post-(\d+)|\/posts\/(\d+)/), id = m && (m[1] || m[2]);
      return id ? h.find(p => (p.k + '/').includes('/post-' + id + '/') || (p.k + '/').includes('/posts/' + id + '/') || p.k.endsWith('#post-' + id)) : null;
    }).filter(Boolean);
    if (exact.length) return { entry: furthest(exact), approx: false };
    // Otherwise: the thread page you last visited. The date of its newest post is an upper bound on how far you read, so the result is marked approximate.
    const pages = items.filter(it => !/\/threadmarks/.test(it.url)).sort((a, b) => (b.lastVisitTime || 0) - (a.lastVisitTime || 0));
    if (!pages.length) return null;
    const got = await fetchChecked(pages[0].url, {}, s.hostGapSec * 1000);
    if (got.bad || got.res.status === 304) return null;
    const times = await domCall('xfTimes', { text: got.res.text });
    const e = times.length ? M.chapterAtOrBefore(h, Math.max(...times)) : null;
    return e ? { entry: e, approx: true } : null;
  }
  for (const e of h.slice(-60).reverse()) {                                         // generic: was this chapter's address ever opened? newest first
    if (!/^(\/|https?:)/.test(e.k)) continue;
    const visits = await api.history.getVisits({ url: new URL(e.k, rec.url).href }).catch(() => []);
    if (visits.length) return { entry: e, approx: false };
  }
  return null;
}

async function scanHistory(ids) {                                                   // ids: [id...] or 'unknown' (every story with no known place)
  if (!(await hasHistory())) return { ok: false, error: 'Access to your browsing history hasn’t been allowed.' };
  const { recs, settings } = await loadAll(), now = Date.now(), found = {};
  for (const r of recs.filter(x => ids === 'unknown' ? !x.read : ids.includes(x.id))) {
    let hit = null;
    try { hit = await historyPlace(r, settings); } catch (e) { /* skip this one */ }
    found[r.id] = hit ? { title: hit.entry.t, approx: hit.approx } : null;
    if (hit) await mutate(r.id, x => M.applyRead(x, hit.entry, 'history', now, hit.approx));
  }
  await updateBadge();
  return { ok: true, found };
}

async function onObserved(m, sender) {
  const s = await getSettings(), now = Date.now();
  if (!Array.isArray(m.posts) || !m.posts.length) return { ok: true };
  const clean = m.posts.filter(p => p && typeof p.key === 'string' && Number.isFinite(p.ts)).map(p => ({ title: String(p.title || '').slice(0, 140), key: p.key, ts: p.ts, hasTime: !!p.hasTime, legacy: typeof p.legacy === 'string' ? p.legacy : undefined }));
  await mutate(m.id, r => m.complete
    ? M.applyOutcome(r, { ok: true, via: 'page', posts: clean, author: m.author }, s, now, { visit: true }).rec
    : M.absorb(r, clean));
  await Promise.all([reschedule(), updateBadge()]);
  if (m.complete && sender && sender.tab && sender.tab.id !== undefined) await visitDone(sender.tab.id, m.id);
  return { ok: true };
}

const handlers = {
  add: m => addSeries(m.draft),
  remove: m => removeSeries(m.id),
  update: m => (M.isGroupId(m.id) ? updateGroup(m.id.slice(2), m.patch || {}) : updateSeries(m.id, m.patch || {})),
  openDashboard: m => openDashboard(m && m.id, m && m.filters),
  link: m => linkSeries(m.ids, m.title),
  unlink: m => unlinkSeries(m.id),
  markSeen: m => markSeen(m.id),
  checkAll: async () => { const { recs } = await loadAll(); enqueue(recs.filter(r => !r.paused), true); return { ok: true, count: recs.length }; },
  checkOne: async m => { const rs = (await Promise.all(expandIds([m.id], await getGroups()).map(getRec))).filter(Boolean); if (rs.length) enqueue(rs, true); return { ok: !!rs.length }; },
  setSettings: m => setSettings(m.patch || {}),
  backupNow: () => runBackup(true),
  import: m => importData(m.data),
  setDisplay: m => setDisplay(m.patch),
  scanList: m => scanList(m),
  importBatch: m => importBatch(m),
  bulkStop: () => bulkStop(),
  bulkResume: () => bulkResume(),
  bulkClear: async () => { await locked(() => api.storage.local.remove('bulk')); return { ok: true }; },
  importRequest: async m => { if (m.request) await api.storage.local.set({ importRequest: { request: m.request, at: Date.now() } }); else await api.storage.local.remove('importRequest'); return { ok: true }; },
  pending: async m => { if (m.draft) await api.storage.local.set({ pending: { draft: m.draft, at: Date.now() } }); else await api.storage.local.remove('pending'); return { ok: true }; },
  accessChanged: async () => { permCache.clear(); await syncContentScripts(); wireNotifications(); return { ok: true }; },
  page: m => onPage(m.url),
  read: m => onRead(m),
  setPlace: m => setPlaceFor(m),
  keepPlace: m => keepPlaceFor(m),
  scanHistory: async m => {
    const groups = await getGroups(), ids = m.ids === 'unknown' ? 'unknown' : expandIds(Array.isArray(m.ids) ? m.ids.filter(x => typeof x === 'string') : [], groups), r = await scanHistory(ids);
    if (r && r.found) for (const id of (Array.isArray(m.ids) ? m.ids : [])) if (M.isGroupId(id) && groups[id.slice(2)]) r.found[id] = groups[id.slice(2)].members.map(x => r.found[x]).find(Boolean) || null;
    return r;
  },
  observed: (m, sender) => onObserved(m, sender),
  openForCheck: async m => openForCheck(expandIds(Array.isArray(m.ids) ? m.ids.filter(x => typeof x === 'string') : [], await getGroups())),
};

api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== 'string' || !handlers[msg.type] || (sender && sender.id && sender.id !== api.runtime.id)) return undefined;
  const letGo = holdAwake();                                                            // adding a story or scanning a list can take a while
  Promise.resolve().then(() => handlers[msg.type](msg, sender)).catch(e => ({ ok: false, error: String((e && e.message) || e) }))
    .then(r => { letGo(); try { sendResponse(r); } catch (e) { /* the sender went away */ } });
  return true;                                                                          // the answer comes later (Chrome does not accept a returned promise; Firefox accepts this too)
});
api.alarms.onAlarm.addListener(a => {
  if (a.name === 'tick') onTick(); else if (a.name === 'bulk') resumeBulk(); else if (a.name === 'visit') tidyVisit().catch(() => {});
  else if (a.name === 'backup') runBackup(false).catch(() => {}); else if (a.name === 'quiet') flushHeld().catch(() => {});
});
// If the browser closed the popup while showing the permission prompt, finish the add the popup started (the popup saves its draft to storage before asking).
if (api.permissions && api.permissions.onAdded) api.permissions.onAdded.addListener(async perms => {
  permCache.clear(); wireNotifications();
  if (((perms && perms.permissions) || []).includes('history')) scanHistory('unknown').catch(() => {});
  try {
    const first = (await api.storage.local.get('pending')).pending;
    if (!first || Date.now() - first.at > 10 * MIN) return;
    const origin = new URL(first.draft.url).origin + '/*';
    if (!((perms && perms.origins) || []).includes(origin)) return;
    await sleep(1500);                                                      // if the popup is still open it clears `pending` and does the add itself
    const still = (await api.storage.local.get('pending')).pending;
    if (!still || still.at !== first.at) return;
    await api.storage.local.remove('pending');
    await addSeries(still.draft);
  } catch (e) { /* if this fails, the user can press Track again */ }
});
if (api.permissions && api.permissions.onRemoved) api.permissions.onRemoved.addListener(() => { permCache.clear(); syncContentScripts(); });

api.runtime.onInstalled.addListener(async details => {
  const cur = await api.storage.local.get('settings');
  if (!cur.settings) await api.storage.local.set({ settings: M.DEFAULT_SETTINGS });
  wireNotifications(); await syncContentScripts(); await recomputeAll();
  await reschedule(); await updateBadge(); await ensureBackupAlarm(); await flushHeld();
});
api.runtime.onStartup.addListener(async () => {                                      // alarms are cleared when the browser restarts; reschedule checks, starting after a delay of 45 to 75 seconds
  wireNotifications(); await setVisit({ tabs: {}, queue: [] }); await reschedule(45000 + Math.random() * 30000); await updateBadge(); await ensureBackupAlarm(); await flushHeld();
});
wireNotifications();
resumeBulk().catch(() => {});                                                       // resume an import that was running when this page was unloaded
