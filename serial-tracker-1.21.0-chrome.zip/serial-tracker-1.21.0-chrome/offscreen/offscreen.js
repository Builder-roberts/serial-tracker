// Serial Tracker - offscreen page reader (Chrome). Answers the background worker's requests; see lib/domops.js.
'use strict';
(function () {
  const api = typeof browser !== 'undefined' ? browser : chrome;
  const D = self.ST.domops;
  api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || msg.target !== 'offscreen' || (sender && sender.id && sender.id !== api.runtime.id)) return false;   // not for this page
    const op = D.ops[msg.op];
    if (typeof op !== 'function') { sendResponse({ error: 'Unknown request: ' + msg.op }); return false; }
    try { sendResponse({ json: D.enc(op(msg.args || {})) }); } catch (e) { sendResponse({ error: String((e && e.message) || e) }); }
    return false;                                                                // answered right away
  });
})();
