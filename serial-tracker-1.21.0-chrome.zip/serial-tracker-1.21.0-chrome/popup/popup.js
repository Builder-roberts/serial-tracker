// Serial Tracker - toolbar popup.
(async function () {
  'use strict';
  const api = typeof browser !== 'undefined' ? browser : chrome;
  const { model: M, adapters: AD, ui: U, filters: F } = self.ST, { ce } = U;
  const $ = id => document.getElementById(id);
  let data, tab, idn;
  U.wireLinks({ closeAfter: true });                                     // web links open as browser tabs, never inside the add-on

  // ---------------------------------------------------------------- up next + footer
  // Up next uses the dashboard's filter. It can't be changed here: the button opens the dashboard's filter panel instead.
  function renderNext() {
    const now = Date.now(), f = F.stored(), rows = M.annotate(data.recs, now).filter(({ rec, st }) => F.matches(rec, st, f, now)), top = M.upNext(rows, data.settings.upNextPopup, now);
    const sw = $('filter-open'), label = F.summary(f, data.recs); sw.textContent = 'Filter: ' + label;
    sw.title = 'Up next shows the stories that match the dashboard’s filter. Click to change the filter on the dashboard.';
    sw.setAttribute('aria-label', 'Filter: ' + label + '. Up next follows the dashboard’s filter. Open the dashboard to change it.');
    $('next-list').replaceChildren(...top.map(({ rec, st }) => {
      const d = U.describeRec(rec, st, now), home = U.resumeUrl(rec);
      return ce('li', { class: 'ni t-' + d.tone },
        ce('div', { class: 'ni-head' },
          ce('a', { class: 'ni-title', href: home || '#', target: '_blank', rel: 'noopener', title: rec.title, onclick: () => { if (rec.unread && !M.placeOf(rec).known) U.send({ type: 'markSeen', id: rec.id }); } }, rec.title),
          U.unreadPill(rec),
          ce('button', { class: 'iconbtn ni-open', type: 'button', title: 'Show this story in the dashboard', 'aria-label': 'Show in dashboard: ' + rec.title, onclick: () => U.send({ type: 'openDashboard', id: rec.id }).then(() => window.close()) }, U.icon('open'))),
        ce('div', { class: 'ni-eta' }, ce('strong', {}, d.big), ce('span', {}, d.sub)),
        U.meter(st));
    }));
    const empty = $('next-empty'), n = data.recs.length;
    empty.hidden = top.length > 0;
    empty.textContent = !n ? 'Nothing tracked yet. Open a story and track it from here.'
      : F.count(f) ? 'Nothing matches the dashboard’s filter right now. Change the filter on the dashboard.'
      : 'No predictions yet. A schedule appears after about a week of chapters; the dashboard shows what has been read so far.';
    renderFooter();
  }
  function renderFooter() {
    const run = data.run || {}, btn = $('check'), note = $('foot-note'), now = Date.now();
    btn.disabled = !!run.running || !data.recs.length;
    btn.textContent = run.running ? 'Checking ' + Math.min(run.done + 1, run.total) + ' of ' + run.total + '…' : 'Check all now';
    const unread = data.recs.reduce((a, r) => a + M.unreadOf(r), 0), stuck = U.needsVisit(data.real);
    $('visit').hidden = !stuck.length;
    $('visit').textContent = stuck.length === 1 ? 'Open the page that needs a check' : 'Open ' + stuck.length + ' pages that need a check';
    note.textContent = run.running ? (run.current ? 'Reading ' + run.current : '')
      : [run.finishedAt ? 'Last checked ' + U.ago(run.finishedAt, now) + '.' : '', unread ? unread + ' unread ' + (unread === 1 ? 'chapter.' : 'chapters.') : ''].filter(Boolean).join(' ');
  }

  // ---------------------------------------------------------------- tracking this page
  async function liveProbe() {                                          // read the page you're looking at (works behind logins and bot checks)
    try {
      await api.scripting.executeScript({ target: { tabId: tab.id }, files: ['lib/adapters.js'] });
      let [r] = await api.scripting.executeScript({ target: { tabId: tab.id }, func: () => globalThis.ST.adapters.probeAsync(document, location.href) });      // also reads the site's feed when the page lists no chapters
      if (!r || !r.result) [r] = await api.scripting.executeScript({ target: { tabId: tab.id }, func: () => globalThis.ST.adapters.probe(document, location.href) });
      return (r && r.result) || null;
    } catch (e) { return null; }
  }

  function trackedView(mine) {
    const now = Date.now(), box = ce('div', { class: 'sheet' });
    mine.forEach(source => {
      const story = data.recs.find(v => v.members && v.members.includes(source.id)), rec = story || source;      // a source of a merged story shows the story
      const st = M.statusOf(rec, now), d = U.describeRec(rec, st, now);
      const stop = ce('button', { class: 'btn quiet danger', type: 'button' }, 'Stop tracking');
      let armed = false;
      stop.addEventListener('click', async () => {
        if (!armed) { armed = true; stop.textContent = 'Click again to stop'; setTimeout(() => { armed = false; stop.textContent = 'Stop tracking'; }, 4000); return; }
        await U.send({ type: 'remove', id: source.id }); await refresh();
      });
      const star = ce('button', { class: 'iconbtn star', type: 'button', 'aria-pressed': String(rec.favorite), 'aria-label': 'Favorite', title: 'Favorite',
        onclick: async () => { await U.send({ type: 'update', id: rec.id, patch: { favorite: !rec.favorite } }); await refresh(); } }, U.icon('star', rec.favorite));
      const mute = ce('button', { class: 'iconbtn mute', type: 'button', 'aria-pressed': String(!!rec.silenced), 'aria-label': 'Silenced', title: rec.silenced ? 'Silenced: no notifications or badge' : 'Silence: no notifications or badge',
        onclick: async () => { await U.send({ type: 'update', id: rec.id, patch: { silenced: !rec.silenced } }); await refresh(); } }, U.icon(rec.silenced ? 'bellOff' : 'bell'));
      const archive = ce('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Archive this story (requires WebToEpub)', title: 'Archive this story (requires WebToEpub). Opens its chapter list for it.',
        onclick: async () => { const u = U.safeHref(rec.url); if (u) { await api.tabs.create({ url: u }); window.close(); } } }, U.icon('archive'));
      box.appendChild(ce('div', { class: 'mine' },
        ce('p', { class: 'lead' }, story ? 'Part of “' + story.title + '” (' + story.members.length + ' sources)' : mine.length > 1 || rec.filter ? rec.title : 'You’re tracking this story.'),
        star, mute, archive,
        ce('p', { class: 'when' }, d.big + (d.sub ? '. ' + d.sub : '') + '.'),
        (() => { const pl = M.placeOf(rec); return ce('p', { class: 'when' }, !pl.known ? 'Your place isn’t known yet.'
          : (pl.read.approx ? 'You’re around ' : 'You’re on ') + (pl.entry ? pl.entry.t : pl.read.t) + (pl.behind ? ', ' + pl.behind + (pl.atLeast ? '+' : '') + ' unread.' : ', caught up.')); })(),
        U.openedOffer(rec, refresh),
        rec.state && rec.state.blockedUrl ? ce('p', { class: 'when bad' }, rec.state.lastError || 'It needs a page opened.') : null,
        rec.state && rec.state.blockedUrl ? ce('div', { class: 'row-actions' }, ce('button', { class: 'btn', type: 'button', onclick: async () => { await U.send({ type: 'openForCheck', ids: [rec.id] }); window.close(); } }, U.visitLabel(rec.state.lastErrorKind)), rec.autoOpen ? null : ce('button', { class: 'linkbtn', type: 'button', title: 'From now on, open this page in a background tab whenever a check is stopped, without asking', onclick: async () => { await U.send({ type: 'update', id: rec.id, patch: { autoOpen: true } }); window.close(); } }, 'Open it automatically from now on')) : null,
        ce('div', { class: 'row-actions' }, story ? ce('button', { class: 'btn quiet', type: 'button', onclick: async () => { await U.send({ type: 'unlink', id: source.id }); await refresh(); } }, 'Separate this source') : null, stop)));
    });
    return box;
  }

  async function formView(startOpen) {
    const origin = new URL(tab.url).origin, host = new URL(tab.url).host;
    const knownAccess = await api.permissions.contains({ origins: [origin + '/*'] }).catch(() => false);
    const probe = await liveProbe();
    // Lists that don't look like chapters (a comments sidebar) are left out when one that does exists; if none does, all are offered in case the guess is wrong.
    const groups = probe && probe.groups ? (probe.groups.some(g => g.likely) ? probe.groups.filter(g => g.likely) : probe.groups) : null;
    const pick = gs => { if (!gs) return 0; const i = gs.findIndex(g => g.confident); return i >= 0 ? i : Math.max(0, gs.findIndex(g => g.likely)); };
    let gi = pick(groups);
    const auto = idn.adapter === 'kemono' || idn.adapter === 'patreon';
    let titleTouched = false;

    const title = ce('input', { type: 'text', id: 'f-title', value: (probe && probe.pageTitle) || idn.hint || host, autocomplete: 'off', oninput: () => { titleTouched = true; } });
    const filter = ce('input', { type: 'text', id: 'f-filter', autocomplete: 'off', spellcheck: 'false',
      placeholder: auto ? 'Chapter, -poll   or   /^\\d+:/' : 'Optional: only posts containing…' });
    const fav = ce('input', { type: 'checkbox', id: 'f-fav' });
    const preview = ce('p', { class: 'preview', role: 'status' });
    const status = ce('p', { class: 'status', role: 'status' });
    const go = ce('button', { class: 'btn primary', type: 'button' }, 'Track this story');
    // Already tracking this story on another site? Merge them: reading on either site counts, and they appear as one story.
    const near = data.recs.slice().sort((a, b) => (M.likelySame(b.title, title.value) - M.likelySame(a.title, title.value)) || a.title.localeCompare(b.title));
    const same = ce('select', { id: 'f-same', 'aria-label': 'Same story as' }, ce('option', { value: '' }, 'No, it’s a new story'),
      ...near.map(x => ce('option', { value: x.id }, x.title + (M.likelySame(x.title, title.value) ? ' (looks the same)' : ''))));
    if (near.length && M.likelySame(near[0].title, title.value)) same.value = near[0].id;

    const posts = () => (groups ? (groups[gi] ? groups[gi].posts : []) : (probe && probe.sourcePage ? probe.posts : null));
    function update() {
      const m = M.makeMatcher(filter.value), list = posts();
      go.textContent = auto ? (m.empty ? 'Track this author' : 'Track matching posts') : 'Track this story';
      if (auto && !titleTouched && probe && probe.author) title.value = m.empty ? probe.author : probe.author + ' (filtered)';
      preview.className = 'preview';
      if (m.error) { preview.classList.add('bad'); preview.textContent = m.error; return; }
      if (!list) {
        preview.textContent = idn.adapter === 'xenforo' ? 'Chapters are read from the story’s Threadmarks page.'
          : idn.adapter === 'royalroad' ? 'Chapters are read from the story’s main page.'
          : idn.adapter === 'scribblehub' ? 'Chapters are read from the story’s feed and main page.'
          : idn.adapter === 'ao3' ? 'Chapters are read from the work’s chapter index. It shows the date of each chapter but not the time.'
          : idn.adapter === 'wattpad' ? 'Chapters and their dates are read from the story’s own data on Wattpad. Track it from the story’s page, not from a chapter.'
          : idn.adapter === 'ffn' ? 'The story’s “updated” date is read from its page. Track it from the story’s own page.'
          : idn.adapter === 'novelupdates' ? 'Releases are read from the table on the series page. It shows the date of each release but not the time.'
          : idn.adapter === 'webnovel' ? 'Chapters are read from the book’s catalog page (open the book, then Catalog). It shows when each chapter was added, as a date or “2 days ago”.'
          : idn.adapter === 'patreon' ? 'The creator’s public post list is read, including posts locked to patrons, so you don’t need a membership. Use the filter to follow only the chapters.'
          : m.empty ? 'Every post from this author will be tracked.' : 'This is a single post, so there’s no list to preview. The filter is applied when the author’s posts are read.';
        return;
      }
      if (!list.length) { preview.classList.add('bad'); preview.textContent = 'No chapter list was found on this page.'; return; }
      const sel = groups && groups[gi], pm = (probe && probe.meta) || {};
      if (sel && sel.feedUrl) { preview.textContent = 'This page lists no chapters, so the site’s feed is followed instead (' + list.length + ' posts). It holds every post, so use “Only posts matching” to follow just the chapters.'; return; }
      if (sel && !sel.likely) { preview.classList.add('bad'); preview.textContent = 'This list doesn’t look like chapters (' + sel.label + '). Track it only if it is the right one.'; return; }
      if (pm.pageCount > 1 && pm.desc === false) { preview.textContent = 'This list is split over ' + pm.pageCount + ' pages, oldest first. The newest chapters are read from its last page. ' + list.length + ' on this page.'; return; }
      if (pm.pageCount > 1 && pm.desc === true && pm.page > 1) { preview.classList.add('bad'); preview.textContent = 'This is page ' + pm.page + ' of ' + pm.pageCount + ', and the newest chapters are on the first page. Open the first page, then track it from there.'; return; }
      const hit = list.filter(p => m.test(p.title));
      preview.textContent = m.empty ? (auto ? 'Every post from this author will be tracked. ' : '') + list.length + ' on this page.'
        : hit.length + ' of ' + list.length + ' posts on this page match' + (hit.length ? '. Latest: “' + hit[hit.length - 1].title + '”' : '. Nothing matches yet, but it will be watched.');
    }
    filter.addEventListener('input', update);

    const kids = [];
    kids.push(ce('label', { class: 'field' }, ce('span', {}, 'Name'), title));
    if (groups && groups.length > 1) {
      kids.push(ce('fieldset', { class: 'groups' }, ce('legend', {}, 'Which list holds the chapters?'),
        ...groups.slice(0, 4).map((g, i) => ce('label', {},
          ce('input', { type: 'radio', name: 'grp', checked: i === gi, onchange: () => { gi = i; update(); } }),
          ce('span', {}, g.n + ' rows' + (g.confident ? ', looks like chapters' : '')),
          ce('small', {}, 'Latest: ' + (g.sample[g.sample.length - 1] || '')))))); 
    }
    if (idn.filterable) {
      kids.push(ce('label', { class: 'field' }, ce('span', {}, 'Only posts matching'), filter,
        ce('small', {}, auto ? 'Leave empty to follow every post.' : 'Leave empty to follow every post in the list.')));
      kids.push(U.filterHelp(filter, (posts() || []).map(p => p.title)));
    }
    kids.push(preview);
    const about = AD.get(idn.adapter);
    if (about && about.note) kids.push(ce('p', { class: about.stamp ? 'preview bad' : 'hint' }, about.note));      // a site that can't be tracked the usual way says so before you press Track
    kids.push(ce('label', { class: 'check' }, fav, ce('span', {}, 'Favorite')));
    if (near.length) kids.push(ce('label', { class: 'field' }, ce('span', {}, 'Already following this story elsewhere?'), same));
    if (!knownAccess) kids.push(ce('p', { class: 'perm-note' }, U.PERM_WHY.site(host)));
    kids.push(ce('div', { class: 'row-actions' }, go), status);
    const form = ce('form', { class: 'sheet', onsubmit: e => e.preventDefault() }, ...kids);
    const wrap = ce('details', { class: 'track-fold' }, ce('summary', {}, 'Track this story'), form);
    wrap.open = !!startOpen;
    if (groups && !groups.length) { go.disabled = true; status.className = 'status bad'; status.textContent = 'No list of chapters with dates was found on this page. Open the page that lists the chapters and try again. Some sites show no dates in their chapter list, and a schedule can’t be learned without them.'; }
    update();

    go.addEventListener('click', async () => {
      const g = groups && groups[gi], list = posts();
      const draft = {
        url: tab.url, title: title.value, filter: filter.value, favorite: fav.checked, author: probe && probe.author, feedUrl: probe && probe.feedUrl,
        meta: probe && probe.meta, generic: g ? { sig: g.sig, tagKey: g.tagKey, feed: g.feedUrl || undefined } : null, seedPosts: list && (probe && (probe.sourcePage || groups)) ? list : [],
      };
      let ok = true;
      if (!knownAccess) {
        // The permission request must start synchronously in the click handler. Firefox may close this popup while asking, so the draft is
        // saved to storage first; if the popup closes, the background script finishes the add when the permission is granted.
        const asked = api.permissions.request({ origins: [origin + '/*'] }).catch(() => false);
        await U.send({ type: 'pending', draft });
        ok = await asked;
        if (!ok) { await U.send({ type: 'pending', draft: null }); status.className = 'status bad'; status.textContent = U.permDeclined('site', host); return; }
        await U.send({ type: 'pending', draft: null });
      }
      go.disabled = true; status.className = 'status'; status.textContent = 'Reading the chapter list…';
      const res = await U.send({ type: 'add', draft });
      if (res && !res.ok && res.id && /Already/.test(res.error || '')) { await refresh(); return; }      // the background script already completed the add
      if (!res || !res.ok) {
        go.disabled = false; status.className = 'status bad';
        status.replaceChildren((res && res.error) || 'Something went wrong.');
        const href = res && U.fixableByVisit(res.kind) ? U.safeHref(idn.sourceUrl) : null;
        if (href) status.append(' ', ce('a', { href, target: '_blank', rel: 'noopener' }, U.sourceLabel(idn.adapter)), ', then press Track again there.');
        return;
      }
      if (same.value && res.id) await U.send({ type: 'link', ids: [res.id, same.value] });
      await refresh();
    });
    return wrap;
  }

  // A page that lists many stories (Royal Road follows, a forum's watched threads): offer to import them all.
  async function listView() {
    let list = null;
    try {
      await api.scripting.executeScript({ target: { tabId: tab.id }, files: ['lib/adapters.js'] });
      const [r] = await api.scripting.executeScript({ target: { tabId: tab.id }, func: () => globalThis.ST.adapters.parseList(document, location.href) });
      list = (r && r.result) || null;
    } catch (e) { /* not readable from here: fall back to the normal view */ }
    if (!list || !list.items.length) return null;
    const origin = new URL(tab.url).origin, host = new URL(tab.url).host;
    const knownAccess = await api.permissions.contains({ origins: [origin + '/*'] }).catch(() => false);
    const have = new Set(data.real.map(r => r.id.split('#')[0]));
    const fresh = list.items.filter(i => { const d = AD.identify(i.url); return d && !have.has(d.key); }).length;
    const status = ce('p', { class: 'status', role: 'status' });
    const go = ce('button', { class: 'btn primary', type: 'button' }, 'Choose and import…');
    go.addEventListener('click', async () => {
      if (!knownAccess) {                                                  // the permission request must run directly in the click handler
        const ok = await api.permissions.request({ origins: [origin + '/*'] }).catch(() => false);
        if (!ok) { status.className = 'status bad'; status.textContent = U.permDeclined('site', host).replace('its stories can’t be checked for new chapters', 'the rest of the list can’t be read'); return; }
        await U.send({ type: 'accessChanged' });
      }
      await U.send({ type: 'importRequest', request: { url: tab.url, seed: { items: list.items, next: list.next, label: list.label, curated: list.curated } } });
      U.send({ type: 'openDashboard' }).then(() => window.close());
    });
    return ce('div', { class: 'sheet' },
      ce('p', { class: 'lead' }, list.label),
      ce('p', { class: 'hint' }, list.items.length + (list.items.length === 1 ? ' story' : ' stories') + ' on this page' + (fresh < list.items.length ? ', ' + fresh + ' not tracked yet' : '') + '. The other pages of the list are read too, then you choose which to add.'),
      !knownAccess ? ce('p', { class: 'perm-note' }, U.PERM_WHY.site(host)) : null,
      ce('div', { class: 'row-actions' }, go), status);
  }

  async function renderTrack() {
    const box = $('track'); box.replaceChildren();
    if (tab && tab.url && AD.looksLikeList(tab.url)) {
      box.appendChild(ce('p', { class: 'hint' }, 'Reading this page…'));
      const lv = await listView();
      if (lv) { box.replaceChildren(lv); return; }
      box.replaceChildren();
    }
    idn = tab && tab.url ? AD.identify(tab.url) : null;
    if (!idn) { box.appendChild(ce('p', { class: 'hint' }, 'Open a story page, then click here to track it.')); return; }
    const mine = data.real.filter(r => r.adapter === idn.adapter && r.id.split('#')[0] === idn.key);
    if (mine.length) box.appendChild(trackedView(mine));
    if (!mine.length) { box.appendChild(ce('p', { class: 'hint' }, 'Reading this page…')); box.replaceChildren(await formView()); }
    else if (idn.filterable) {
      const more = ce('button', { class: 'btn', type: 'button', style: 'margin-top:10px' }, 'Track another story from here');
      more.addEventListener('click', async () => { more.replaceWith(ce('p', { class: 'hint' }, 'Reading this page…')); box.lastChild.replaceWith(await formView(true)); });
      box.appendChild(more);
    }
  }

  async function refresh() { data = await U.loadData(); renderNext(); await renderTrack(); }

  $('close').addEventListener('click', () => window.close());
  $('dash').addEventListener('click', () => { U.send({ type: 'openDashboard' }).then(() => window.close()); });
  $('filter-open').addEventListener('click', () => { U.send({ type: 'openDashboard', filters: true }).then(() => window.close()); });
  $('check').addEventListener('click', () => U.send({ type: 'checkAll' }));
  $('visit').addEventListener('click', async () => { await U.send({ type: 'openForCheck', ids: U.needsVisit(data.real).map(r => r.id) }); window.close(); });

  data = await U.loadData();
  [tab] = await api.tabs.query({ active: true, currentWindow: true });
  renderNext(); await renderTrack();
  api.storage.onChanged.addListener(async () => { data = await U.loadData(); renderNext(); });   // progress while checking; the form is left alone
})();
