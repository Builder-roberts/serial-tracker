// Serial Tracker - page observer. Registered only for sites you track (see syncContentScripts in background.js).
// It does two things, both from the page you are already looking at (no extra requests):
//   1. On the page that lists a tracked story's chapters: read the list. This counts as a check without any request.
//   2. On a chapter or thread page of a tracked story: work out which chapter you are on, so "unread" means
//      "after where you actually are" instead of assuming you are caught up.
//        - Royal Road / Kemono-style: the address identifies the chapter; counted after you have been on it a few seconds.
//        - XenForo threads: how far down you have scrolled, as the date of the furthest post you've reached.
(function () {
  'use strict';
  const api = typeof browser !== 'undefined' ? browser : chrome;
  const AD = globalThis.ST && globalThis.ST.adapters;
  if (!AD || window.top !== window || globalThis.__stObserver) return;
  globalThis.__stObserver = true;

  const DWELL = 4000;                                                      // ms on a page before it counts as "reading"
  const send = m => api.runtime.sendMessage(m).catch(() => {});

  // ---- 1. chapter lists
  let tries = 0;
  async function observeLists(lists) {
    let found = false;
    for (const rec of lists) {
      let parsed;
      try { parsed = AD.parseFor(document, location.href, rec); } catch (e) { continue; }
      if (!parsed.posts.length) continue;
      found = true;
      send({
        type: 'observed', id: rec.id, posts: parsed.posts, author: parsed.author,
        complete: AD.isNewest(rec.adapter, parsed, location.href),          // does this page show the newest chapters?
      });
    }
    if (!found && ++tries < 6) setTimeout(() => observeLists(lists), 2000);  // lists that fill in after the page loads
  }

  // ---- 2. reading position
  function whenVisible(ms, fn) {                                           // run fn once the page has been open ms, and is on screen
    setTimeout(function go() {
      if (document.visibilityState === 'visible') fn();
      else document.addEventListener('visibilitychange', function h() { if (document.visibilityState === 'visible') { document.removeEventListener('visibilitychange', h); fn(); } });
    }, ms);
  }
  function trackReading(reads) {
    const exact = reads.filter(r => r.mode === 'exact'), scroll = reads.filter(r => r.mode === 'scroll');
    if (exact.length) whenVisible(DWELL, () => exact.forEach(r => send({ type: 'read', id: r.id, url: location.href })));
    if (scroll.length) {
      let best = 0, idle;
      const report = () => {
        const items = AD.reading.xfPosts(document).map(p => ({ top: p.el.getBoundingClientRect().top, t: p.t }));
        const T = AD.reading.furthestSeen(items, window.innerHeight * 0.85);
        if (T > best) { best = T; scroll.forEach(r => send({ type: 'read', id: r.id, url: location.href, T })); }   // only ever further down
      };
      whenVisible(DWELL, report);
      window.addEventListener('scroll', () => { clearTimeout(idle); idle = setTimeout(() => { if (document.visibilityState === 'visible') report(); }, 2500); }, { passive: true });
    }
  }

  (async function run() {
    let info;
    try { info = await api.runtime.sendMessage({ type: 'page', url: location.href }); } catch (e) { return; }
    if (!info) return;                                                     // not a page of a tracked story: do nothing
    if (info.lists && info.lists.length) observeLists(info.lists);
    if (info.reads && info.reads.length) trackReading(info.reads);
  })();
})();
