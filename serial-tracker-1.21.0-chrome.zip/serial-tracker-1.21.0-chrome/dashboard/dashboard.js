// Serial Tracker - dashboard. Reads storage directly; every change goes through the background page.
(function () {
  'use strict';
  const api = typeof browser !== 'undefined' ? browser : chrome;
  const { model: M, engine: E, adapters: AD, ui: U, filters: F } = self.ST, { ce } = U;
  U.wireLinks();                                                                     // web links open as browser tabs, never inside the add-on
  const $ = id => document.getElementById(id);
  const parse = s => { try { return JSON.parse(s) || {}; } catch (e) { return {}; } };
  const prefs = Object.assign({ sort: 'smart' }, parse(localStorage.getItem('st-prefs')));
  const savePrefs = () => { try { localStorage.setItem('st-prefs', JSON.stringify(prefs)); } catch (e) { /* private mode */ } };
  F.migrate(prefs); savePrefs();                                                   // earlier versions kept three separate switches; they are now part of the filters
  if (prefs.sort === 'next' || !prefs.smartSort) { prefs.sort = 'smart'; prefs.smartSort = true; savePrefs(); }
  const S = { recs: [], real: [], groups: {}, settings: M.DEFAULT_SETTINGS, run: {}, sched: {}, bulk: null, scan: {}, q: '', open: new Set(), view: new Map() };      // view: story id -> the source whose view is shown (none = the whole story)
  const ANDROID = /Android/i.test(navigator.userAgent);                      // some optional features may not exist there; say so instead of "wasn't allowed"
  const noAndroid = (what, plain) => (ANDROID ? what + ' isn’t available in this browser on Android.' : plain);
  const plural = (n, one, many) => n + ' ' + (n === 1 ? one : many);

  // ---------------------------------------------------------------- feedback
  let toastTimer;
  function toast(msg) {
    const t = $('toast'); t.textContent = msg; t.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true; }, 4500);
  }
  async function act(msg) {                                              // send a message to the background script and show any error
    const res = await U.send(msg).catch(e => ({ ok: false, error: String(e) }));
    if (res && res.ok === false) toast(res.error || 'That didn’t work.');
    return res;
  }

  // ---------------------------------------------------------------- header
  function renderHeader(now) {
    const n = S.recs.length, unread = S.recs.reduce((a, r) => a + M.unreadOf(r), 0), run = S.run || {};
    $('summary').replaceChildren(ce('span', {}, plural(n, 'story', 'stories') + ' tracked'), unread ? ce('span', {}, plural(unread, 'unread chapter', 'unread chapters')) : null);
    const btn = $('check-all');
    btn.disabled = !!run.running || !n;
    btn.textContent = run.running ? 'Checking…' : 'Check all now';
    const line = $('runline'), bar = $('runbar');
    const bulk = S.bulk && S.bulk.running ? S.bulk : null;
    bar.hidden = !(run.running || bulk);
    if (bulk) {
      bar.max = Math.max(bulk.total || 1, 1); bar.value = bulk.done || 0;
      line.textContent = 'Importing ' + Math.min((bulk.done || 0) + 1, bulk.total || 1) + ' of ' + (bulk.total || 1) + (bulk.current ? ': ' + bulk.current : '');
    } else if (run.running) {
      bar.max = Math.max(run.total || 1, 1); bar.value = run.done || 0;
      line.textContent = 'Checking ' + Math.min((run.done || 0) + 1, run.total || 1) + ' of ' + (run.total || 1) + (run.current ? ': ' + run.current : '');
    } else {
      const bits = [];
      if (run.finishedAt) bits.push('Last check finished ' + U.ago(run.finishedAt, now) + '.');
      if (S.settings.auto === 'off') bits.push('Automatic checking is off.');
      else if (S.sched && S.sched.nextAt) bits.push('Next automatic check ' + (S.sched.nextAt <= now + 60000 ? 'any moment' : U.ago(S.sched.nextAt, now)) + '.');
      line.textContent = bits.join(' ');
    }
  }

  function renderVisitLine() {
    const box = $('visitline'), need = U.needsVisit(S.real);
    box.hidden = !need.length;
    if (!need.length) { box.replaceChildren(); return; }
    box.replaceChildren(
      ce('p', {}, plural(need.length, 'story', 'stories') + ' can’t be read in the background. '
        + (need.length === 1 ? 'Its page opens' : 'Their pages open one at a time') + ', ' + (need.length === 1 ? 'is' : 'each is') + ' read once ' + (need.length === 1 ? 'it has' : 'it has') + ' loaded'
        + (S.settings.closeVisitTab ? ', and ' + (need.length === 1 ? 'the tab' : 'its tab') + ' closes.' : '.')),
      ce('button', { class: 'btn', type: 'button', onclick: () => act({ type: 'openForCheck', ids: need.map(r => r.id) }) }, need.length === 1 ? U.visitLabel(need[0].state.lastErrorKind) : 'Open them one at a time'));
  }

  // ---------------------------------------------------------------- up next
  function renderUpNext(rows, now) {
    const filtered = F.count(prefs.f) > 0, top = M.upNext(rows.filter(({ rec, st }) => F.matches(rec, st, prefs.f, now)), S.settings.upNextDash, now), grid = $('upnext-grid'), empty = $('upnext-empty');
    $('upnext-filter').hidden = !filtered;                                            // the same filter is used by the toolbar popup's Up next
    grid.replaceChildren(...top.map(({ rec, st }) => {
      const d = U.describeRec(rec, st, now), home = U.safeHref(rec.home);
      return ce('article', { class: 'nx t-' + d.tone },
        ce('button', { class: 'iconbtn nx-open', type: 'button', title: 'Show this story in the list below', 'aria-label': 'Show in list: ' + rec.title, onclick: () => showStory(rec.id) }, U.icon('chevron')),
        ce('h3', {}, ce('a', { href: U.resumeUrl(rec) || '#', target: '_blank', rel: 'noopener', onclick: () => markSeen(rec) }, rec.title)),
        ce('p', { class: 'nx-big' }, d.big), U.meter(st),
        ce('div', { class: 'nx-foot' }, ce('p', { class: 'nx-sub muted' }, d.sub), U.unreadPill(rec)));
    }));
    empty.hidden = top.length > 0;
    empty.textContent = !S.recs.length ? ''
      : filtered ? 'Nothing matches your filters right now. Up next, here and in the toolbar popup, follows them: change them under Filters and sort.'
      : 'Nothing has a prediction yet. A schedule needs chapters from three different days; stories still learning are in the list below.';
  }

  // ---------------------------------------------------------------- list
  // WebToEpub can't be driven from here (Firefox has no way to press another extension's button), so this opens the story's
  // chapter list in a tab, which is the page WebToEpub reads, and says what to do next.
  async function archive(rec) {
    const url = U.safeHref(rec.url); if (!url) return;
    await api.tabs.create({ url });
    toast('Opened ' + rec.title + '. Click the WebToEpub button in the toolbar there (requires WebToEpub).');
  }
  const markSeen = rec => { if (rec.unread && !M.placeOf(rec).known) U.send({ type: 'markSeen', id: rec.id }); };   // only clears the unread count when the reading position is unknown
  const patch = (id, p) => act({ type: 'update', id, patch: p });

  // ---- where you are
  function placeLine(rec) {
    const p = M.placeOf(rec), pill = U.unreadPill(rec);
    if (!p.known) return ce('p', { class: 'place muted' }, 'Your place isn’t known yet', ce('button', { class: 'linkbtn', type: 'button', onclick: () => { S.open.add(rec.id); render(); } }, 'Set it'), pill);
    const name = p.entry ? p.entry.t : p.read.t, url = p.entry && U.postUrl(rec, p.entry.k), offer = U.openedOffer(rec, reload);
    return ce('p', { class: 'place' }, ce('span', {}, p.read.approx ? 'You’re around ' : 'You’re on ', url ? ce('a', { href: url, target: '_blank', rel: 'noopener' }, name) : name),
      !p.behind && !p.atLeast ? ce('span', { class: 'caught' }, 'caught up') : null, pill, offer);
  }

  function buildPlace(rec, now) {
    const p = M.placeOf(rec), h = rec.history, recent = h.slice(-60).reverse(), say = (t) => { msg.textContent = t; };
    const msg = ce('p', { class: 'msg', role: 'status' });
    const how = !p.known ? 'Not known yet. Open a chapter of this story and the add-on will record it, or choose one below.'
      : (p.read.via === 'manual' ? 'Set by you' : p.read.via === 'history' ? (p.read.approx ? 'Estimated from your browsing history' : 'Found in your browsing history') : 'Noticed while you were reading') + ', ' + U.ago(p.read.at, now) + '.';
    const here = p.known && p.entry && recent.includes(p.entry);
    const sel = ce('select', { 'aria-label': 'Your place', onchange: e => act({ type: 'setPlace', id: rec.id, k: e.target.value }) },
      ce('option', { value: '', disabled: true, selected: !here }, p.known ? 'Change it…' : 'Choose where you are…'),
      h.length ? ce('option', { value: 'latest' }, 'I’m caught up (' + h[h.length - 1].t + ')') : null,
      ...recent.map(e => ce('option', { value: e.k, selected: here && p.entry === e }, e.t)));
    const find = ce('button', { class: 'btn', type: 'button', onclick: async () => {
      if (!S.histPerm) {                                                           // the permission request must run directly in the click handler
        const ok = await api.permissions.request({ permissions: ['history'] }).catch(() => false);
        if (!ok) { toast(noAndroid('Browsing history', U.permDeclined('history'))); return; }
        S.histPerm = true;
      }
      say('Looking…');
      const r = await act({ type: 'scanHistory', ids: [rec.id] }), f = r && r.found && r.found[rec.id];
      say(f ? 'Found: ' + f.title + (f.approx ? ' (approximate: the last page you opened)' : '') : 'Nothing in your history for this story.');
    } }, S.histPerm ? 'Find it from my browsing history' : 'Allow history access and find it');
    return ce('div', { class: 'placebox' }, ce('h4', {}, 'Your place'), ce('p', { class: 'muted' }, how), U.openedOffer(rec, reload), ce('div', { class: 'pair' }, sel, find), S.histPerm ? null : ce('p', { class: 'perm-note' }, U.PERM_WHY.history), msg);
  }

  function renderPlaceNote() {
    const box = $('placeline'), unknown = S.recs.filter(r => !r.read && r.history.length);
    box.hidden = !(unknown.length && !S.histPerm && !prefs.hideHistoryNote);
    if (box.hidden) { box.replaceChildren(); return; }
    box.replaceChildren(
      ce('p', {}, plural(unknown.length, 'story has', 'stories have') + ' no known place yet. It records which chapter you open as you read; for stories you were already reading, it can search your browsing history.'),
      ce('p', { class: 'perm-note' }, U.PERM_WHY.history),
      ce('div', { class: 'row-actions' },
        ce('button', { class: 'btn', type: 'button', onclick: async () => {
          const ok = await api.permissions.request({ permissions: ['history'] }).catch(() => false);   // the permission request must run directly in the click handler
          if (!ok) { toast(noAndroid('Browsing history', U.permDeclined('history'))); return; }
          S.histPerm = true; render();
          const r = await act({ type: 'scanHistory', ids: 'unknown' }), n = r && r.found ? Object.values(r.found).filter(Boolean).length : 0;
          toast(n ? 'Found your place in ' + plural(n, 'story', 'stories') + '.' : 'Nothing in your history for these yet. Reading a chapter will set it.');
        } }, 'Allow history access'),
        ce('button', { class: 'btn quiet', type: 'button', onclick: () => { prefs.hideHistoryNote = true; savePrefs(); render(); } }, 'Not now')));
  }

  // The sources of a merged story, each with how far it is behind the one that has the newest chapter.
  // They also switch the details between the whole story and one source; clicking the chosen one again goes back to the whole story.
  function sourceChips(rec) {
    const chosen = S.view.get(rec.id);
    return ce('p', { class: 'sources' }, ...rec.sources.map(x => {
      const note = x.leader ? (rec.sources.length > 1 && x.behind === 0 && rec.sources.some(o => o !== x && o.behind > 0) ? 'ahead' : 'up to date') : (x.behind ? x.behind + ' behind' : 'up to date');
      const bad = x.rec.state && x.rec.state.failures, on = chosen === x.rec.id;
      return ce('button', { class: 'src' + (x.leader ? ' lead' : '') + (bad ? ' bad' : ''), type: 'button', 'aria-pressed': String(on),
        title: on ? 'Showing only ' + U.siteLabel(x.rec) + ' in the details. Click to show the whole story again.' : 'Show only ' + U.siteLabel(x.rec) + ' in the details',
        onclick: () => { if (on) S.view.delete(rec.id); else S.view.set(rec.id, x.rec.id); S.open.add(rec.id); render(); } },
        ce('span', { class: 'name' }, U.siteLabel(x.rec)), ce('small', {}, bad ? 'needs attention' : note));
    }));
  }

  function buildRow(rec, st, now) {
    const d = U.describeRec(rec, st, now), open = S.open.has(rec.id), home = U.safeHref(rec.home), s = rec.state || {};
    const latest = rec.history[rec.history.length - 1], latestUrl = latest && U.postUrl(rec, latest.k);
    const flt = rec.filter ? (rec.filter.length > 24 ? 'filtered posts' : 'only posts matching “' + rec.filter + '”') : (rec.kind === 'author' ? 'every post' : '');
    const by = [rec.author ? 'by ' + rec.author : '', U.siteLabel(rec), flt].filter(Boolean).join(', ');
    const byFull = rec.filter ? by + ' (' + rec.filter + ')' : by;
    const detailsId = 'd-' + rec.id.replace(/[^a-z0-9]/gi, '_');

    const main = ce('div', { class: 'row-main' },
      ce('div', { class: 'flags' },
        ce('button', { class: 'iconbtn star', type: 'button', 'aria-pressed': String(!!rec.favorite), 'aria-label': 'Favorite: ' + rec.title, title: 'Favorite', onclick: () => patch(rec.id, { favorite: !rec.favorite }) }, U.icon('star', rec.favorite)),
        ce('button', { class: 'iconbtn mute', type: 'button', 'aria-pressed': String(!!rec.silenced), 'aria-label': 'Silenced: ' + rec.title, title: rec.silenced ? 'Silenced: no notifications or badge for this story' : 'Silence: no notifications or badge for this story', onclick: () => patch(rec.id, { silenced: !rec.silenced }) }, U.icon(rec.silenced ? 'bellOff' : 'bell'))),
      ce('div', { class: 'titleblock' },
        ce('h3', {}, ce('a', { href: U.resumeUrl(rec) || '#', target: '_blank', rel: 'noopener', onclick: () => markSeen(rec) }, rec.title)),
        ce('p', { class: 'byline', title: rec.filter ? byFull : null }, by),
        rec.virtual ? sourceChips(rec) : null,
        ce('p', { class: 'latest' },
          latest ? ce('span', {}, 'Latest: ', latestUrl ? ce('a', { href: latestUrl, target: '_blank', rel: 'noopener', onclick: () => markSeen(rec) }, latest.t) : latest.t) : ce('span', { class: 'muted' }, 'No chapters read yet'),
          latest ? ce('span', { class: 'muted' }, U.when(latest, now)) : null,
          rec.ended ? ce('span', { class: 'tag' }, rec.ended === 'finished' ? 'Finished' : 'Abandoned') : rec.paused ? ce('span', { class: 'tag' }, 'Paused') : null,
          rec.priority && rec.favorite && !rec.ended ? ce('span', { class: 'tag' }, 'Checked more often') : null,
          rec.silenced ? ce('span', { class: 'tag' }, 'Silenced') : null,
          M.categoryOf(rec, st, now) === 'toread' ? ce('span', { class: 'tag' }, 'To read') : null),
        placeLine(rec)),
      ce('div', { class: 'eta' }, ce('p', { class: 'big' }, rec.ended ? (rec.ended === 'finished' ? 'Finished' : 'Abandoned') : d.big), rec.ended ? null : U.meter(st), ce('p', { class: 'sub' }, rec.ended ? 'No longer checked' : d.sub)),
      ce('div', { class: 'acts' },
        ce('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Archive this story (requires WebToEpub): ' + rec.title, title: 'Archive this story (requires WebToEpub). Opens its chapter list so WebToEpub can save it.', onclick: () => archive(rec) }, U.icon('archive')),
        ce('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Check now: ' + rec.title, title: 'Check now', onclick: () => { act({ type: 'checkOne', id: rec.id }); toast('Checking ' + rec.title + '…'); } }, U.icon('refresh')),
        ce('button', { class: 'iconbtn', type: 'button', 'aria-expanded': String(open), 'aria-controls': detailsId, 'aria-label': 'Details: ' + rec.title, title: 'Details',
          onclick: () => { if (S.open.has(rec.id)) S.open.delete(rec.id); else S.open.add(rec.id); render(); } }, U.icon('chevron'))));

    const row = ce('li', { class: 'row t-' + d.tone + (rec.paused ? ' paused' : '') + (rec.silenced ? ' silenced' : ''), 'data-id': rec.id }, main);
    if (s.failures && s.lastError) {
      const alert = ce('p', { class: 'alert', role: 'status' }, s.lastError + ' (' + U.ago(s.lastAttempt, now) + ')');
      const target = U.safeHref(s.blockedUrl);
      if (target) alert.appendChild(ce('button', { class: 'btn', type: 'button', title: target, onclick: () => act({ type: 'openForCheck', ids: [rec.id] }) }, U.visitLabel(s.lastErrorKind)));
      if (target && !rec.autoOpen && !S.settings.autoOpenBlocked) alert.appendChild(ce('button', { class: 'linkbtn', type: 'button', title: 'From now on, open this page in a background tab whenever a check is stopped, without asking', onclick: () => { patch(rec.id, { autoOpen: true }); toast('It will open by itself when a check is stopped. Opening it now.'); } }, 'Open it automatically from now on'));
      if (s.lastErrorKind === 'permission') {
        let host = ''; try { host = new URL(rec.url).origin; } catch (e) { /* ignore */ }
        let why = host; try { why = new URL(rec.url).host; } catch (e) { /* ignore */ }
        alert.appendChild(ce('button', { class: 'btn', type: 'button', title: U.PERM_WHY.siteShort(why), onclick: async () => {            // the permission request must run directly in the click handler
          const ok = await api.permissions.request({ origins: [host + '/*'] }).catch(() => false);
          if (ok) { await U.send({ type: 'accessChanged' }); U.send({ type: 'checkOne', id: rec.id }); } else toast(U.permDeclined('site', why)); } }, 'Allow access'));
        alert.appendChild(ce('span', { class: 'perm-note' }, ' ' + U.PERM_WHY.siteShort(why)));
      }
      row.appendChild(alert);
    }
    if (open) row.appendChild(buildDetails(rec, st, now, detailsId));
    return row;
  }

  // Merge this story with another tracked one (or, for a merged story, add one more source).
  function mergeBox(rec) {
    const others = S.recs.filter(r => r.id !== rec.id).sort((a, b) => (M.likelySame(b.title, rec.title) - M.likelySame(a.title, rec.title)) || a.title.localeCompare(b.title));
    if (!others.length) return ce('p', { class: 'muted' }, 'Track the same story on another site, then merge them here.');
    const sel = ce('select', { 'aria-label': 'Merge with' }, ce('option', { value: '' }, rec.virtual ? 'Add another source…' : 'Merge with another story…'),
      ...others.map(r => ce('option', { value: r.id }, r.title + ' (' + U.siteLabel(r) + ')' + (M.likelySame(r.title, rec.title) ? ', looks like the same story' : ''))));
    const go = ce('button', { class: 'btn', type: 'button', onclick: async () => {
      if (!sel.value) return;
      const r = await act({ type: 'link', ids: [rec.id, sel.value] });
      if (r && r.ok) { S.open.delete(rec.id); if (r.id) S.open.add(r.id); toast('Merged. Reading anywhere counts for the whole story.'); }
    } }, 'Merge');
    return ce('div', { class: 'field' }, ce('span', {}, rec.virtual ? 'Add a source' : 'Same story on another site?'), ce('div', { class: 'pair' }, sel, go));
  }
  // One line per source of a merged story: how it's doing, its numbering offset, and ways to detach or stop it.
  function sourcesBox(rec, now) {
    return ce('div', { class: 'srcbox' }, ce('h4', {}, 'Sources'),
      ce('p', { class: 'muted' }, 'Chapters are matched by number in their titles (or from the oldest one, if a site has no numbers). The release time used for predictions is the earliest any source had the chapter.'),
      ce('ul', { class: 'srclist' }, ...rec.sources.map(x => {
        const r = x.rec, s = r.state || {}, href = U.safeHref(r.url);
        const off = ce('input', { type: 'number', value: String((rec.offsets || {})[r.id] || 0), step: 1, min: -500, max: 500, 'aria-label': 'Numbering offset for ' + U.siteLabel(r),
          onchange: e => patch(rec.id, { offsets: { [r.id]: Number(e.target.value) } }) });
        let armed = false;
        const stop = ce('button', { class: 'btn quiet danger', type: 'button' }, 'Stop tracking this source');
        stop.addEventListener('click', () => { if (!armed) { armed = true; stop.textContent = 'Click again'; setTimeout(() => { armed = false; stop.textContent = 'Stop tracking this source'; }, 4000); return; } act({ type: 'remove', id: r.id }); });
        return ce('li', {},
          ce('div', { class: 'src-main' }, href ? ce('a', { href, target: '_blank', rel: 'noopener' }, U.siteLabel(r)) : U.siteLabel(r), ' ',
            ce('span', { class: 'muted' }, x.leader ? 'has the newest chapter' : x.behind ? x.behind + ' behind' : 'up to date'), ' ',
            ce('span', { class: 'muted' }, x.have + ' chapters' + (x.only ? ', ' + x.only + ' only here' : '') + (s.lastOk ? ', checked ' + U.ago(s.lastOk, now) : ''))),
          s.failures && s.lastError ? ce('p', { class: 'alert' }, s.lastError) : null,
          ce('div', { class: 'src-acts' }, ce('label', { class: 'inline' }, 'Numbering offset ', off),
            ce('button', { class: 'btn', type: 'button', onclick: () => { act({ type: 'checkOne', id: r.id }); toast('Checking ' + U.siteLabel(r) + '…'); } }, 'Check now'),
            ce('button', { class: 'btn', type: 'button', onclick: () => act({ type: 'unlink', id: r.id }) }, 'Separate'), stop));
      })));
  }

  // When a record's next automatic check is, and why. withWhy adds the reason (used for the sources of a merged story).
  function nextCheckText(r, now, withWhy) {
    const s = r.state || {}, why = M.scheduleReason(r, S.settings, now);
    return r.ended ? 'Not checked (' + r.ended + ')' : r.paused ? 'Paused' : S.settings.auto === 'off' ? 'Automatic checking is off'
      : s.nextCheckAt ? (s.nextCheckAt <= now + 60000 ? 'Any moment' : U.ago(s.nextCheckAt, now)) + (withWhy ? ' · ' + why.text : '') : why.text;
  }

  function buildDetails(rec, st, now, id) {
    // What the schedule, calendar and recent chapters describe: the whole story, or one source of a merged story.
    const sel = rec.virtual && rec.sources ? rec.sources.find(x => x.rec.id === S.view.get(rec.id)) : null;
    const vr = sel ? sel.rec : rec, vst = sel ? M.statusOf(vr, now) : st, A = vst.A, vs = vr.state || {}, dl = ce('dl', { class: 'facts' });
    const add = (k, v) => dl.append(ce('dt', {}, k), ce('dd', {}, v));
    if (A) {
      add('Pattern', E.pattern(A) + (A.mode === 'rough' ? ', a rough guess' : ' (days in UTC)'));
      if (!A.dateOnly) add('Usual time', E.hm(A.slot) + ' UTC, ' + new Date(A.next).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) + ' your time');
      add('Reliability', A.rel == null ? 'Too early to tell' : Math.round(A.rel * 100) + '% of expected ' + (A.mode === 'interval' ? 'gaps were on time' : 'days had a chapter'));
      if (!A.dateOnly) add('Timing', '90% within ' + E.spreadText(A.spread) + ' of the usual time');
    } else add('Schedule', vst.state === 'empty' ? 'No chapters found yet.' : 'Needs chapters from three different days. ' + plural(vst.count, 'chapter', 'chapters') + ' so far.');
    const how = AD.get(vr.adapter);
    if (how && how.note) add('About this site', how.note);
    add(how && how.stamp ? 'Updates seen' : 'Chapters found', String(vr.history.length) + (vr.history.length >= M.HISTORY_CAP ? ' (most recent kept)' : ''));
    if (M.isLagged(vr)) { const lag = M.archiveLag(vr); add('Archive delay', lag ? 'Chapters usually appear here about ' + E.dur(lag) + ' after the author uploads them (from chapters first seen here live).' : 'Chapters show up here some time after the author uploads them.'); }
    if (rec.virtual && rec.sources && !sel) {                              // whole merged story: each source has its own checks
      for (const x of rec.sources) {
        const nm = U.siteLabel(x.rec);
        add(nm + ': last checked', (x.rec.state || {}).lastOk ? U.ago(x.rec.state.lastOk, now) : 'Not yet');
        add(nm + ': next check', nextCheckText(x.rec, now, true));
      }
    } else {
      add('Last checked', vs.lastOk ? U.ago(vs.lastOk, now) : 'Not yet');
      add(sel ? 'Next check' : 'Next automatic check', nextCheckText(vr, now, !!sel));
      if (sel && vs.failures && vs.lastError) add('Last problem', vs.lastError);
    }

    const cals = A ? [U.calendar(A, now, { graceMin: S.settings.graceMin })] : [];
    const label = sel ? U.siteLabel(vr) : '';
    const homeHref = sel ? U.safeHref(vr.home) : null;
    const bar = sel ? ce('p', { class: 'viewbar' },
      homeHref ? ce('a', { href: homeHref, target: '_blank', rel: 'noopener' }, 'Open ' + label) : null,
      ce('button', { class: 'btn', type: 'button', onclick: () => { act({ type: 'checkOne', id: vr.id }); toast('Checking ' + label + '…'); } }, 'Check now'),
      ce('button', { class: 'linkbtn', type: 'button', onclick: () => { S.view.delete(rec.id); render(); } }, 'Show the whole story')) : null;
    const left = ce('div', {}, ce('h4', {}, sel ? 'Schedule: ' + label : 'Schedule'), bar, dl, ...cals, cals.length ? U.calendarLegend() : null);
    const recent = vr.history.slice(-8).reverse();
    const right = ce('div', {}, ce('h4', {}, sel ? 'Recent chapters: ' + label : 'Recent chapters'),
      recent.length ? ce('ol', { class: 'recent' }, ...recent.map(p => { const u = U.postUrl(vr, p.k);
        return ce('li', {}, u ? ce('a', { href: u, target: '_blank', rel: 'noopener', title: p.t }, p.t) : ce('span', {}, p.t), ce('span', {}, U.when(p, now))); }))
        : ce('p', { class: 'muted' }, 'None yet.'));

    // ---- editing
    const msg = ce('p', { class: 'msg', role: 'status' });
    const say = (t, bad) => { msg.textContent = t; msg.className = 'msg' + (bad ? ' bad' : ''); };
    const name = ce('input', { type: 'text', value: rec.title, 'aria-label': 'Name', onchange: e => patch(rec.id, { title: e.target.value || rec.title }) });
    const fields = [ce('label', { class: 'field' }, ce('span', {}, 'Name'), name)];
    if (!rec.virtual && (rec.adapter === 'kemono' || rec.adapter === 'patreon' || rec.adapter === 'generic')) {
      const f = ce('input', { type: 'text', value: rec.filter, autocomplete: 'off', spellcheck: 'false', 'aria-label': 'Only posts matching' });
      const apply = ce('button', { class: 'btn', type: 'button', onclick: async () => {
        apply.disabled = true; say('Re-reading the page…');
        const r = await U.send({ type: 'update', id: rec.id, patch: { filter: f.value } });
        apply.disabled = false;
        if (r && r.ok) { say('Updated.'); } else say((r && r.error) || 'Couldn’t update.', true);
      } }, 'Apply');
      fields.push(ce('label', { class: 'field' }, ce('span', {}, 'Only posts matching'), ce('div', { class: 'pair' }, f, apply),
        ce('small', {}, 'Leave empty to follow every post. Changing it re-reads the page.')));
      fields.push(U.filterHelp(f, rec.history.map(p => p.t)));
    }
    const feed = rec.virtual ? null : ce('input', { type: 'url', value: rec.feedUrl || '', placeholder: 'https://…', 'aria-label': 'Site feed', onchange: e => {
      const v = e.target.value.trim(); if (v && !U.safeHref(v)) { say('That doesn’t look like a web address.', true); return; } patch(rec.id, { feedUrl: v }); } });
    if (feed) fields.push(ce('label', { class: 'field' }, ce('span', {}, 'Site feed (optional)'), feed,
      ce('small', {}, 'An RSS or Atom address for this story. Automatic checks ask the feed whether anything changed before loading the page. A feed request is much smaller.')));
    fields.push(ce('label', { class: 'field' }, ce('span', {}, 'Status'),
      ce('select', { 'aria-label': 'Status', onchange: e => patch(rec.id, { ended: e.target.value }) },
        ce('option', { value: '', selected: !rec.ended }, 'Ongoing'), ce('option', { value: 'finished', selected: rec.ended === 'finished' }, 'Finished'), ce('option', { value: 'abandoned', selected: rec.ended === 'abandoned' }, 'Abandoned')),
      ce('small', {}, 'Finished and abandoned stories are tagged, shown at the bottom, and never checked, counted on the badge or notified about.')));
    fields.push(ce('label', { class: 'check' }, ce('input', { type: 'checkbox', checked: !!rec.paused, disabled: !!rec.ended, onchange: e => patch(rec.id, { paused: e.target.checked }) }), ce('span', {}, 'Pause checking this story')));
    fields.push(ce('label', { class: 'check' }, ce('input', { type: 'checkbox', checked: !!rec.autoOpen || !!S.settings.autoOpenBlocked, disabled: !!S.settings.autoOpenBlocked, onchange: e => patch(rec.id, { autoOpen: e.target.checked }) }),
      ce('span', {}, 'Open its page by itself when it can’t be read in the background', ce('small', {}, S.settings.autoOpenBlocked ? 'On for every story (Settings → Request limits and feeds).' : 'When a bot check or login page stops a check, the page opens in a background tab, is read once it has loaded, and the tab closes, so you aren’t asked. A tab that needs a click is closed after 3 minutes and the usual button stays.'))));
    if (rec.favorite && !rec.ended) fields.push(ce('label', { class: 'check' }, ce('input', { type: 'checkbox', checked: !!rec.priority, onchange: e => patch(rec.id, { priority: e.target.checked }) }),
      ce('span', {}, 'Check this favorite more often', ce('small', {}, 'Looks about a minute after the predicted time, then again every 10 to 30 minutes at first while nothing has appeared (instead of 30 minutes to hours), and at least every 12 hours. Uses more requests to this site.'))));
    let armed = false;
    const rmLabel = rec.virtual ? 'Stop tracking all sources' : 'Stop tracking';
    const rm = ce('button', { class: 'btn quiet danger', type: 'button' }, rmLabel);
    rm.addEventListener('click', () => {
      if (!armed) { armed = true; rm.textContent = 'Click again to stop tracking'; setTimeout(() => { armed = false; rm.textContent = rmLabel; }, 4000); return; }
      S.open.delete(rec.id); act({ type: 'remove', id: rec.id });
    });
    fields.push(mergeBox(rec), ce('div', { class: 'field' }, rm));
    const src = rec.virtual ? null : U.safeHref(rec.url);
    const edit = ce('div', { class: 'edit' }, ...fields, msg, rec.virtual ? null : ce('p', { class: 'source' }, 'Checks read ', src ? ce('a', { href: src, target: '_blank', rel: 'noopener' }, rec.url) : rec.url));
    return ce('div', { class: 'details', id }, left, right, buildPlace(rec, now), rec.virtual ? sourcesBox(rec, now) : null, edit);
  }

  function renderList(rows, now) {
    const q = S.q.trim().toLowerCase(), words = q.split(/\s+/).filter(Boolean);
    let shown = rows.filter(({ rec, st }) => (!words.length || words.every(w => F.searchText(rec).includes(w))) && F.matches(rec, st, prefs.f, now));
    shown = M.sortRows(shown, prefs.sort, now, { reverse: !!prefs.sortRev, then: prefs.sortThen });
    renderFilters(rows, shown, now);
    const nodes = [], labels = Object.fromEntries(M.CATEGORIES.map(c => [c.key, c.label]));
    let lastCat = null;
    for (const { rec, st } of shown) {
      if (prefs.sort === 'smart' && S.settings.groupHeadings) {                                        // group headings only make sense in the category order
        const c = M.categoryOf(rec, st, now);
        if (c !== lastCat) { nodes.push(ce('li', { class: 'cat-head', 'data-cat': c }, ce('h3', {}, labels[c]))); lastCat = c; }
      }
      nodes.push(buildRow(rec, st, now));
    }
    $('list').replaceChildren(...nodes);
    const empty = $('empty'); empty.replaceChildren();
    empty.hidden = shown.length > 0;
    if (!S.recs.length) {
      empty.append(ce('h3', {}, 'Nothing tracked yet'), ce('p', {}, 'Open a story or an author’s page, click the Serial Tracker button in the toolbar, and choose Track.'),
        ce('p', {}, 'It learns each story’s release pattern from its chapter dates, and checks again shortly after the next one is expected.'));
    } else if (!shown.length) empty.append(ce('h3', {}, 'No stories match'), ce('p', {}, 'Nothing fits the search and filters together.'), ce('button', { class: 'btn', type: 'button', onclick: clearFilters }, 'Clear the search and filters'));
  }

  function render() {
    const now = Date.now(), rows = M.annotate(S.recs, now);
    renderHeader(now); renderVisitLine(); renderPlaceNote(); renderUpNext(rows, now); renderList(rows, now);
    if ($('schedule').open) renderSchedule(now);
  }
  const typing = () => { const a = document.activeElement; return !!(a && /^(INPUT|SELECT|TEXTAREA)$/.test(a.tagName) && a.closest('#list')); };
  let pending;
  function renderSoon() { clearTimeout(pending); pending = setTimeout(() => { if (typing()) return; render(); }, 120); }
  $('list').addEventListener('focusout', () => setTimeout(renderSoon, 200));

  async function reload() { const d = await U.loadData(); S.recs = d.recs; S.real = d.real; S.groups = d.groups; S.settings = d.settings; S.run = d.run; S.sched = d.sched; S.bulk = d.bulk; S.scan = d.scan; S.histPerm = await api.permissions.contains({ permissions: ['history'] }).catch(() => false); render(); }

  // ---------------------------------------------------------------- check schedule: what is planned next, and when
  const timeFmt = new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit' }), dayFmt = new Intl.DateTimeFormat(undefined, { weekday: 'short' }), dateFmt = new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric' });
  const startOfDay = t => { const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); };
  function whenText(t, now) {
    const d = (startOfDay(t) - startOfDay(now)) / 864e5;
    return d === 0 ? timeFmt.format(t) : d === 1 ? 'Tomorrow ' + timeFmt.format(t) : d > 1 && d < 7 ? dayFmt.format(t) + ' ' + timeFmt.format(t) : dateFmt.format(t) + ', ' + timeFmt.format(t);
  }
  function renderSchedule(now) {
    now = now || Date.now();
    const run = S.run || {}, rows = S.real.map(rec => ({ rec, at: rec.state && rec.state.nextCheckAt, why: M.scheduleReason(rec, S.settings, now) }));
    const checking = run.running ? (run.current ? 'Checking now: ' + run.current + ' (' + (run.done || 0) + ' of ' + (run.total || 0) + ' done).' : 'Checking now: ' + (run.done || 0) + ' of ' + (run.total || 0) + ' done.') : '';
    const scheduled = rows.filter(r => r.at).sort((a, b) => a.at - b.at), none = rows.filter(r => !r.at).sort((a, b) => a.rec.title.localeCompare(b.rec.title));
    const next = scheduled.find(r => r.at > now);
    $('sch-run').textContent = checking || (scheduled.length ? 'Nothing is being checked right now.' + (next ? ' Next check ' + E.dur(next.at - now).replace(/^/, 'in ') + '.' : '') : 'No checks are planned.');
    const eod = startOfDay(now) + 864e5, BUCKETS = [
      ['Due now: waiting its turn', r => r.at <= now], ['In the next hour', r => r.at <= now + 36e5], ['Later today', r => r.at < eod], ['Tomorrow', r => r.at < eod + 864e5],
      ['This week', r => r.at < eod + 6 * 864e5], ['Later', () => true],
    ];
    const out = [], used = new Set();
    for (const [label, test] of BUCKETS) {
      const group = scheduled.filter(r => !used.has(r) && test(r)); group.forEach(r => used.add(r));
      if (!group.length) continue;
      out.push(ce('h3', { class: 'sch-h' }, label, ce('span', {}, plural(group.length, 'story', 'stories'))), ...group.map(r => schedRow(r, now, label.startsWith('Due now'))));
    }
    if (none.length) out.push(ce('h3', { class: 'sch-h' }, 'Not scheduled', ce('span', {}, plural(none.length, 'story', 'stories'))), ...none.map(r => schedRow(r, now, false)));
    if (!out.length) out.push(ce('p', { class: 'muted' }, 'No stories are tracked yet.'));
    $('sch-list').replaceChildren(...out);
  }
  function schedRow({ rec, at, why }, now, due) {
    const story = S.recs.find(v => v.members && v.members.includes(rec.id)) || rec, s = rec.state || {}, going = S.run && S.run.running && S.run.current && S.run.current.includes(rec.title);
    return ce('div', { class: 'sch-row' + (going ? ' now' : '') },
      ce('div', { class: 'sch-when' }, at ? ce('strong', {}, going ? 'Now' : due ? 'Due' : whenText(at, now)) : ce('strong', {}, '—'), at ? ce('small', {}, going ? 'being checked' : at <= now ? 'since ' + whenText(at, now) : 'in ' + E.dur(at - now)) : null),
      ce('div', { class: 'sch-main' },
        ce('button', { class: 'sch-title', type: 'button', title: 'Show this story in the list', onclick: () => { $('schedule').close(); showStory(story.id); } }, rec.title),
        ce('span', { class: 'sch-why ' + why.kind }, why.text),
        ce('span', { class: 'sch-why' }, U.siteLabel(rec) + (s.lastOk ? ' · last checked ' + U.ago(s.lastOk, now) : ' · not checked yet'))),
      rec.paused || rec.ended ? ce('span') : ce('button', { class: 'btn quiet', type: 'button', title: 'Check this story now', onclick: () => act({ type: 'checkOne', id: rec.id }) }, 'Check now'));
  }
  const schedDlg = $('schedule');
  $('open-schedule').addEventListener('click', async () => { await reload(); renderSchedule(); schedDlg.showModal(); });
  schedDlg.querySelector('.dclose').addEventListener('click', () => schedDlg.close());
  setInterval(() => { if (schedDlg.open) reload().then(() => renderSchedule()).catch(() => {}); }, 30000);

  // ---------------------------------------------------------------- jump to a story (from Up next, or the popup's #story=<id> address)
  function showStory(id) {
    const rec = S.recs.find(r => r.id === id); if (!rec) return;
    S.q = ''; $('q').value = '';                                                    // make sure nothing filters it out
    prefs.f = F.empty();
    savePrefs(); S.open.add(id); render();
    const row = [...$('list').children].find(li => li.dataset.id === id);
    if (row) { row.scrollIntoView({ block: 'start', behavior: 'smooth' }); row.classList.add('flash'); setTimeout(() => row.classList.remove('flash'), 1800); }
  }
  function takeHash() {
    if (location.hash === '#filters') {                                             // the toolbar popup's filter button
      history.replaceState(null, '', location.pathname + location.search);
      prefs.fOpen = true; savePrefs(); render();
      const p = $('fpanel'); if (p && p.scrollIntoView) p.scrollIntoView({ block: 'center' });
      return;
    }
    const m = location.hash.match(/^#story=(.+)$/); if (!m) return;
    let id; try { id = decodeURIComponent(m[1]); } catch (e) { return; }
    history.replaceState(null, '', location.pathname + location.search);          // so the same link can be used again
    showStory(id);
  }
  window.addEventListener('hashchange', () => reload().then(takeHash));

  // ---------------------------------------------------------------- controls
  $('check-all').addEventListener('click', () => { act({ type: 'checkAll' }); toast('Checking all stories. Different sites are checked side by side; requests to the same site are spaced out, so this can take a while.'); });
  $('q').addEventListener('input', e => { S.q = e.target.value; render(); });
  if (!M.SORTS.some(x => x[0] === prefs.sort)) prefs.sort = 'smart';
  if (!M.SORTS.some(x => x[0] === prefs.sortThen)) prefs.sortThen = '';
  $('f-toggle').addEventListener('click', () => { prefs.fOpen = !prefs.fOpen; savePrefs(); render(); });

  // ---------------------------------------------------------------- filters
  // Choose any number of options in each group. In a group a story fits if it matches ANY choice; it must pass every group that has a choice.
  function toggleOpt(group, opt) {
    const list = prefs.f[group], i = list.indexOf(opt);
    if (i < 0) list.push(opt); else list.splice(i, 1);
    S.focusOpt = group + '|' + opt; savePrefs(); render();
  }
  function clearFilters() { prefs.f = F.empty(); S.q = ''; $('q').value = ''; savePrefs(); render(); }
  function optionLabel(group, opt, rows) {
    if (group === 'sites') { const s = F.sitesOf(rows.map(r => r.rec)).find(x => x.key === opt); return s ? s.label : opt; }
    const g = F.GROUPS.find(x => x.key === group), o = g.options().find(x => x[0] === opt); return o ? o[1] : opt;
  }
  function renderFilters(rows, shown, now) {
    const n = F.count(prefs.f), sortCustom = !!(prefs.sort !== 'smart' || prefs.sortRev || prefs.sortThen), active = n > 0 || S.q.trim() !== '' || sortCustom;
    const sortName = k => (M.SORTS.find(x => x[0] === k) || [k, k])[1];
    const btn = $('f-toggle'), badge = $('f-count');
    btn.setAttribute('aria-expanded', String(!!prefs.fOpen)); btn.setAttribute('aria-pressed', String(n > 0));
    badge.hidden = !n; badge.textContent = String(n);

    // the active filters, each one removable, and how many stories they leave
    const sum = $('fsummary'); sum.hidden = !active;
    if (active) {
      const pills = [];
      if (S.q.trim()) pills.push(ce('button', { class: 'pill', type: 'button', title: 'Clear the search', onclick: () => { S.q = ''; $('q').value = ''; render(); } }, 'Search: “' + S.q.trim() + '” ', ce('span', { 'aria-hidden': 'true' }, '×')));
      for (const g of F.GROUPS) for (const o of prefs.f[g.key]) pills.push(ce('button', { class: 'pill', type: 'button', title: 'Remove this filter', onclick: () => toggleOpt(g.key, o) },
        g.label + ': ' + optionLabel(g.key, o, rows) + ' ', ce('span', { 'aria-hidden': 'true' }, '×')));
      if (sortCustom) pills.push(ce('button', { class: 'pill', type: 'button', title: 'Back to the plain order', onclick: () => { prefs.sort = 'smart'; prefs.sortRev = false; prefs.sortThen = ''; savePrefs(); render(); } },
        'Sort: ' + sortName(prefs.sort) + (prefs.sortRev ? ', reversed' : '') + (prefs.sortThen ? ', then ' + sortName(prefs.sortThen) : '') + ' ', ce('span', { 'aria-hidden': 'true' }, '×')));
      sum.replaceChildren(ce('p', { class: 'fcountline', role: 'status' }, 'Showing ' + shown.length + ' of ' + rows.length + (rows.length === 1 ? ' story' : ' stories')), ...pills,
        n || S.q.trim() ? ce('button', { class: 'linkbtn', type: 'button', onclick: clearFilters }, 'Clear all filters') : null);
    }

    // the panel: every option with how many stories it would show with the other choices kept
    const panel = $('fpanel'); panel.hidden = !prefs.fOpen;
    if (!prefs.fOpen) { panel.replaceChildren(); return; }
    const words = S.q.trim().toLowerCase().split(/\s+/).filter(Boolean), base = rows.filter(({ rec }) => !words.length || words.every(w => F.searchText(rec).includes(w)));
    const cell = (g, key, label) => {
      const on = prefs.f[g.key].includes(key), f2 = Object.assign({}, prefs.f, { [g.key]: g.all ? [...new Set(prefs.f[g.key].concat(key))] : [key] });
      const k = base.filter(({ rec, st }) => F.matches(rec, st, f2, now)).length;               // what you would see with this option added (or, in a group, chosen alone)
      return ce('button', { class: 'chip fopt', type: 'button', 'aria-pressed': String(on), 'data-fo': g.key + '|' + key, disabled: !on && !k, title: on ? 'Remove this filter' : k + (k === 1 ? ' story' : ' stories'),
        onclick: () => toggleOpt(g.key, key) }, label, ce('span', { class: 'n' }, String(k)));
    };
    const sites = F.sitesOf(rows.map(r => r.rec));
    const sections = F.GROUPS.map(g => {
      const opts = g.key === 'sites' ? sites.map(s => [s.key, s.label]) : g.options();
      if (g.key === 'sites' && sites.length < 2 && !prefs.f.sites.length) return null;                 // one website: nothing to choose between
      return ce('fieldset', { class: 'fgroup' }, ce('legend', {}, g.label), ce('div', { class: 'fopts' }, ...opts.map(([k, l]) => cell(g, k, l))),
        g.all ? ce('small', {}, 'A story must be every one you choose.') : null);
    }).filter(Boolean);
    const pickSort = k => { prefs.sort = k; if (prefs.sortThen === k) prefs.sortThen = ''; S.focusOpt = 'sort|' + k; savePrefs(); render(); };
    const thenSel = ce('select', { id: 'sort-then', 'aria-label': 'Then sort by', onchange: e => { prefs.sortThen = e.target.value; savePrefs(); render(); } },
      ce('option', { value: '' }, 'Nothing'), ...M.SORTS.filter(([k]) => k !== prefs.sort && k !== 'smart').map(([k, l]) => ce('option', { value: k, selected: prefs.sortThen === k }, l)));
    const sortBox = ce('fieldset', { class: 'fgroup fsort' }, ce('legend', {}, 'Sort by'),
      ce('div', { class: 'fopts' }, ...M.SORTS.map(([k, l]) => ce('button', { class: 'chip fopt', type: 'button', 'aria-pressed': String(prefs.sort === k), 'data-fo': 'sort|' + k, onclick: () => pickSort(k) }, l))),
      ce('div', { class: 'fsortrow' },
        ce('button', { class: 'chip fopt', type: 'button', 'aria-pressed': String(!!prefs.sortRev), 'data-fo': 'sort|reverse', title: 'Flip the order of the chosen sort', onclick: () => { prefs.sortRev = !prefs.sortRev; S.focusOpt = 'sort|reverse'; savePrefs(); render(); } }, 'Reverse the order'),
        ce('label', { class: 'inline' }, 'Then by ', thenSel)),
      ce('small', {}, 'Stories that tie on the chosen sort are ordered by the second choice, then by category.'));
    thenSel.value = prefs.sortThen || '';
    panel.replaceChildren(sortBox, ...sections, ce('div', { class: 'factions' }, ce('p', { class: 'muted small' }, 'Within a group, a story fits if it matches any choice. It must pass every group you have chosen in. The number is how many stories you would see.'),
      ce('button', { class: 'btn quiet', type: 'button', disabled: !n, onclick: () => { prefs.f = F.empty(); savePrefs(); render(); } }, 'Clear filters')));
    if (S.focusOpt) { const b = panel.querySelector('[data-fo="' + S.focusOpt.replace(/"/g, '') + '"]'); if (b && !b.disabled) b.focus(); S.focusOpt = null; }
  }

  // ---------------------------------------------------------------- settings
  const dlg = $('settings'), form = dlg.querySelector('form');
  // ---- numbers: a type-in box plus a menu of suggestions. Picking a suggestion fills the box.
  const NUMS = {
    recentHours: { unit: 'hours', min: 1, max: 48, presets: [[1, '1 hour'], [2, '2 hours'], [3, '3 hours'], [6, '6 hours'], [12, '12 hours'], [24, '24 hours']] },
    stoppedUnread: { unit: 'unread', min: 1, max: 500, presets: [[5], [10], [15], [20], [30], [50]] },
    badgeMaxUnread: { unit: 'unread', min: 0, max: 20, presets: [[0, '0 (favorites only)'], [1], [2], [3], [5], [10]] },
    notifyMax: { unit: 'notifications', min: 1, max: 10, presets: [[1], [2], [4], [6], [10]] },
    upNextPopup: { unit: 'stories', min: 1, max: 15, presets: [[3], [5], [8], [10], [15]] },
    upNextDash: { unit: 'stories', min: 1, max: 24, presets: [[3], [4], [6], [8], [12], [24]] },
    marinateDays: { unit: 'days', min: 1, max: 365, presets: [[7, '7 days'], [14, '14 days'], [21, '21 days'], [30, '30 days'], [60, '60 days'], [90, '90 days']] },
  };
  function buildCombos() {
    for (const host of form.querySelectorAll('[data-combo]')) {
      const key = host.dataset.combo, c = NUMS[key];
      const num = ce('input', { type: 'number', id: key, min: c.min, max: c.max, step: 1, inputmode: 'numeric', 'data-look': '', 'data-num': '', 'aria-label': host.dataset.label || key });
      const pick = ce('select', { 'data-preset': key, 'aria-label': 'Suggestions for ' + (host.dataset.label || key),
        onchange: e => { if (e.target.value === '') return; num.value = e.target.value; e.target.value = ''; num.dispatchEvent(new Event('change', { bubbles: true })); } },
        ce('option', { value: '' }, 'Suggestions'), ...c.presets.map(([v, l]) => ce('option', { value: String(v) }, l || String(v))));
      host.replaceChildren(num, pick, ce('span', { class: 'unit' }, c.unit));
    }
  }
  for (const id of ['quietFrom', 'quietTo']) for (let h = 0; h < 24; h++) $(id).appendChild(ce('option', { value: String(h) }, new Date(2000, 0, 1, h).toLocaleTimeString([], { hour: 'numeric' })));
  async function showBackupNote() {
    const b = (await api.storage.local.get('backup')).backup || {}, note = $('backup-note');
    note.textContent = b.error && b.failedAt && b.failedAt > (b.at || 0) ? 'The last backup failed: ' + b.error : b.at ? 'Last backup ' + U.ago(b.at, Date.now()) + '.' : 'No backup saved yet.';
  }
  function fillSettings() {
    const s = S.settings;
    form.elements.auto.value = s.auto === 'off' ? 'off' : 'smart';
    $('useFeeds').checked = s.useFeeds; $('safety').value = String(s.safetyHours); $('gap').value = String(s.hostGapSec);
    $('badge').checked = s.badge; $('notify').checked = s.notify; $('closeVisitTab').checked = s.closeVisitTab; $('autoOpenBlocked').checked = !!s.autoOpenBlocked;
    $('quietOn').checked = !!s.quietOn; $('quietFrom').value = String(s.quietFrom); $('quietTo').value = String(s.quietTo);
    $('quietFrom').disabled = $('quietTo').disabled = !s.quietOn;
    $('autoBackup').checked = !!s.autoBackup; $('backupDays').value = String([1, 7, 30].includes(s.backupDays) ? s.backupDays : 7); $('backupDays').disabled = !s.autoBackup;
    showBackupNote();
    for (const k in NUMS) $(k).value = String(s[k]);
    for (const k of ['groupHeadings', 'showByline', 'showLatest', 'showMeter']) $(k).checked = !!s[k];
    $('density').value = s.density;
    $('theme').value = s.theme; $('background').value = s.background;
    renderColors();
  }

  // ---- colors: one picker per status. Unset = the theme's own color, shown as the picker's starting value.
  const COLOR_GROUPS = [
    ['Statuses', [['colUpcoming', '--c-upcoming', 'Coming up'], ['colSoon', '--c-soon', 'Due soon'], ['colDue', '--c-due', 'Due now'],
      ['colLate', '--c-late', 'Late'], ['colQuiet', '--c-quiet', 'On a break, or still learning']]],
    ['Categories', [['colRecent', '--c-recent', 'Recently updated'], ['colStopped', '--c-stopped', 'Stopped reading'], ['colSilenced', '--c-silenced', 'Silenced (heading and bell)']]],
    ['Marks', [['colFavorite', '--c-favorite', 'Favorite star'], ['colCaught', '--c-caught', 'Caught up'], ['colUnread', '--c-unread', 'Unread tag and badge']]],
    ['Page', [['bgColor', '--paper', 'Page background'], ['colSurface', '--sheet', 'Cards and panels'], ['colInk', '--ink', 'Text'], ['colMuted', '--muted', 'Secondary text'],
      ['colRule', '--rule', 'Lines and borders'], ['colLink', '--c-link', 'Story titles']]],
    ['Release calendar', [['colCalPost', '--cal-post', 'Chapter day'], ['colCalMulti', '--cal-multi', '2 or more chapters'], ['colCalMiss', '--cal-miss', 'Missed day']]],
  ];
  function renderColors() {
    const root = getComputedStyle(document.documentElement), box = $('colors');
    box.replaceChildren(...COLOR_GROUPS.flatMap(([title, rows]) => [ce('p', { class: 'colors-group', style: 'grid-column: 1 / -1' }, title), ...rows.map(([key, v, label]) => {
      const custom = S.settings[key], eff = (root.getPropertyValue(v) || '').trim();
      const inp = ce('input', { type: 'color', value: custom || (/^#[0-9a-f]{6}$/i.test(eff) ? eff : '#888888'), 'aria-label': label, 'data-look': '', 'data-key': key });
      return ce('div', { class: 'cw' }, inp, ce('span', {}, label), custom ? ce('button', { class: 'linkbtn', type: 'button', onclick: async () => { await act({ type: 'setDisplay', patch: { [key]: '' } }); setTimeout(renderColors, 80); } }, 'Reset') : null);
    })]));
  }
  $('reset-look').addEventListener('click', async () => {
    const patch = {}; M.COLOR_KEYS.concat('bgColor').forEach(k => { patch[k] = ''; });
    await act({ type: 'setDisplay', patch }); setTimeout(renderColors, 80);
  });
  buildCombos();

  // ---- "Restore defaults" for each section of the settings
  const LOOK_KEYS = ['theme', 'background', 'density', 'groupHeadings', 'showByline', 'showLatest', 'showMeter', 'bgColor'].concat(M.COLOR_KEYS);
  for (const fs of form.querySelectorAll('fieldset[data-defaults]')) {
    const keys = fs.dataset.defaults === 'look' ? LOOK_KEYS : fs.dataset.defaults.split(','), name = fs.querySelector('legend').textContent;
    fs.appendChild(ce('div', { class: 'row-actions' }, ce('button', { class: 'btn quiet', type: 'button', title: 'Put every setting in “' + name + '” back to the add-on’s own default', onclick: async () => {
      const patch = {}; keys.forEach(k => { patch[k] = M.DEFAULT_SETTINGS[k]; });
      const r = await act({ type: 'setSettings', patch });
      if (!r || !r.ok) return;
      S.settings = r.settings; fillSettings(); render(); setTimeout(renderColors, 80);
      toast('Defaults restored for “' + name + '”.');
      if (patch.notify && !(await api.permissions.contains({ permissions: ['notifications'] }).catch(() => false))) toast('Notifications are on by default, but the browser hasn’t been given permission yet. Turn the box off and on again to be asked.');
    } }, 'Restore defaults for this section')));
  }

  // ---- what each permission is for, and whether it is allowed now
  async function renderPerms() {
    const all = await api.permissions.getAll().catch(() => ({ permissions: [], origins: [] }));
    const hosts = [...new Set((all.origins || []).map(o => { try { return new URL(o.replace('*://', 'https://').replace(/\*$/, '')).host; } catch (e) { return null; } }).filter(Boolean))].filter(h => h !== '*');
    const has = p => (all.permissions || []).includes(p), row = (name, state, why) => ce('li', {}, ce('strong', {}, name), ' ', ce('span', { class: 'tag' }, state), ce('small', {}, why));
    $('perm-list').replaceChildren(
      row('Sites you track', hosts.length ? 'Allowed: ' + hosts.slice(0, 6).join(', ') + (hosts.length > 6 ? ', and ' + (hosts.length - 6) + ' more' : '') : 'None yet', 'Needed to read each site’s chapter list for new chapters. Asked once per site, the first time you track something there. Royal Road, Scribble Hub, SpaceBattles, SufficientVelocity, QuestionableQuesting and Pawchive are allowed from the start.'),
      row('Notifications', has('notifications') ? 'Allowed' : 'Not allowed', U.PERM_WHY.notifications),
      row('Browsing history', has('history') ? 'Allowed' : 'Not allowed', U.PERM_WHY.history),
      row('Bookmarks', has('bookmarks') ? 'Allowed' : 'Not allowed', U.PERM_WHY.bookmarks),
      row('Downloads', has('downloads') ? 'Allowed' : 'Not allowed', U.PERM_WHY.downloads),
      row('Always on', 'Storage, alarms, scripting, active tab', 'Storage keeps your stories in this browser profile. Alarms time the checks. Scripting and active tab read the page you have open when you press the toolbar button, to track it or import a list. None of these show a prompt.'));
  }
  if (api.permissions && api.permissions.onAdded) { api.permissions.onAdded.addListener(() => renderPerms()); if (api.permissions.onRemoved) api.permissions.onRemoved.addListener(() => renderPerms()); }
  $('open-settings').addEventListener('click', () => { fillSettings(); renderPerms(); dlg.showModal(); });
  dlg.querySelector('.dclose').addEventListener('click', () => dlg.close());
  form.addEventListener('change', async e => {
    const t = e.target;
    if (t.hasAttribute('data-preset')) return;                           // a suggestion was picked: it fills the number box, and that box's own change event saves the value
    if (t.hasAttribute('data-look')) {                                   // display setting: does not affect the check schedule
      const key = t.dataset.key || t.id;
      if (t.hasAttribute('data-num') && (t.value === '' || !Number.isFinite(Number(t.value)))) { t.value = String(S.settings[key]); return; }
      const res = await act({ type: 'setDisplay', patch: { [key]: t.type === 'checkbox' ? t.checked : t.hasAttribute('data-num') ? Number(t.value) : t.value } });
      if (t.hasAttribute('data-num') && res && res.settings) t.value = String(res.settings[key]);      // shows the value after limits are applied
      render();
      setTimeout(renderColors, 80);
      return;
    }
    if (t.id === 'notify' && t.checked) {                                // the permission request must run directly in the click handler
      const ok = await api.permissions.request({ permissions: ['notifications'] }).catch(() => false);
      if (!ok) { t.checked = false; toast(noAndroid('Notifications', U.permDeclined('notifications'))); return; }
      await U.send({ type: 'accessChanged' });
    }
    if (t.id === 'autoBackup' && t.checked) {
      const ok = await api.permissions.request({ permissions: ['downloads'] }).catch(() => false);
      if (!ok) { t.checked = false; toast(noAndroid('Saving backup files', U.permDeclined('downloads')) + (ANDROID ? ' Use Save backup instead.' : '')); return; }
    }
    const next = { auto: form.elements.auto.value, quietOn: $('quietOn').checked, quietFrom: Number($('quietFrom').value), quietTo: Number($('quietTo').value),
      autoBackup: $('autoBackup').checked, backupDays: Number($('backupDays').value), useFeeds: $('useFeeds').checked, safetyHours: Number($('safety').value),
      hostGapSec: Number($('gap').value), badge: $('badge').checked, notify: $('notify').checked, closeVisitTab: $('closeVisitTab').checked, autoOpenBlocked: $('autoOpenBlocked').checked };
    $('quietFrom').disabled = $('quietTo').disabled = !next.quietOn; $('backupDays').disabled = !next.autoBackup;
    await act({ type: 'setSettings', patch: next });
    if (t.id === 'autoBackup' && t.checked) { await act({ type: 'backupNow' }); showBackupNote(); }
  });
  $('export').addEventListener('click', () => {
    const blob = new Blob([JSON.stringify({ app: 'serial-tracker', version: 1, exportedAt: new Date().toISOString(), settings: S.settings, series: S.real, groups: S.groups }, null, 1)], { type: 'application/json' });
    const a = ce('a', { href: URL.createObjectURL(blob), download: 'serial-tracker-' + new Date().toISOString().slice(0, 10) + '.json' });
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  });
  $('backup-now').addEventListener('click', async () => {
    const ok = await api.permissions.request({ permissions: ['downloads'] }).catch(() => false);   // the permission request must run directly in the click handler
    if (!ok) { toast(noAndroid('Saving backup files', U.permDeclined('downloads'))); return; }
    const r = await act({ type: 'backupNow' }); showBackupNote();
    if (r && r.ok) toast('Backup saved to Downloads/Serial Tracker backups.');
  });
  $('export-settings').addEventListener('click', () => {
    const blob = new Blob([JSON.stringify({ app: 'serial-tracker', kind: 'settings', version: 1, exportedAt: new Date().toISOString(), settings: S.settings }, null, 1)], { type: 'application/json' });
    const a = ce('a', { href: URL.createObjectURL(blob), download: 'serial-tracker-settings.json' });
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  });
  $('import-settings').addEventListener('change', async e => {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return;
    let data; try { data = JSON.parse(await f.text()); } catch (err) { toast('That file couldn’t be read.'); return; }
    if (!data || data.app !== 'serial-tracker' || !data.settings || typeof data.settings !== 'object') { toast('That isn’t a Serial Tracker settings file.'); return; }
    const r = await act({ type: 'import', data: { app: data.app, settings: data.settings } });
    if (r && r.ok) { toast('Settings loaded.'); location.reload(); }
  });
  $('import').addEventListener('change', async e => {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return;
    let data; try { data = JSON.parse(await f.text()); } catch (err) { toast('That file couldn’t be read as a backup.'); return; }
    const r = await act({ type: 'import', data });
    if (r && r.ok) {
      const rest = [r.existing ? plural(r.existing, 'was', 'were') + ' already tracked' : '', r.invalid ? plural(r.invalid, 'entry', 'entries') + ' couldn’t be read' : ''].filter(Boolean).join(', ');
      toast((r.imported ? 'Restored ' + plural(r.imported, 'story', 'stories') + (rest ? '; ' + rest : '') + '. Allow access to each site from its row if asked.' : 'Nothing new to restore' + (rest ? ': ' + rest : '') + '.'));
    }
  });

  // ---------------------------------------------------------------- import from a site
  const imp = { items: [], sel: new Set(), label: '', more: false, scanning: false, listUrl: '', fromBookmarks: false };
  const idp = $('importer'), MINUTE = 6e4;
  const SOURCES = [
    ['Royal Road: Follows', 'https://www.royalroad.com/my/follows'], ['Royal Road: Favorites', 'https://www.royalroad.com/my/favorites'], ['Royal Road: Read later', 'https://www.royalroad.com/my/readlater'],
    ['Scribble Hub: Reading list', 'https://www.scribblehub.com/reading-list/'],
    ['SpaceBattles: Watched', 'https://forums.spacebattles.com/watched/threads?unread=0'], ['SufficientVelocity: Watched', 'https://forums.sufficientvelocity.com/watched/threads?unread=0'],
    ['QuestionableQuesting: Watched', 'https://forum.questionablequesting.com/watched/threads?unread=0'],
  ];
  const tracked = () => new Set(S.real.map(r => r.id.split('#')[0]));
  const impMsg = (text, bad, ...extra) => { const m = $('imp-msg'); m.hidden = !text && !extra.length; m.className = 'msg' + (bad ? ' bad' : ''); m.replaceChildren(text || '', ...extra); };

  function renderImporter() {
    if (!idp.open) return;
    const b = S.bulk, working = !!(b && (b.running || b.paused || b.finishedAt));
    $('imp-pick').hidden = working || imp.scanning; $('imp-run').hidden = !working;
    $('imp-found').hidden = working || !imp.items.length;
    if (working) {
      $('imp-msg').hidden = true;
      $('imp-bar').max = Math.max(b.total, 1); $('imp-bar').value = b.done;
      $('imp-run-line').textContent = b.running ? 'Adding ' + Math.min(b.done + 1, b.total) + ' of ' + b.total + (b.current ? ': ' + b.current : '') + '. You can close this window; the import continues.'
        : b.paused ? 'Paused after ' + b.done + ' of ' + b.total + ': the site asked to slow down. Resume when you’re ready.'
        : (b.cancelled ? 'Stopped. ' : 'Finished. ') + 'Added ' + plural(b.added, 'story', 'stories') + '.';
      const notes = [];
      if (b.existing) notes.push(ce('li', {}, plural(b.existing, 'was', 'were') + ' already tracked.'));
      if (b.visit) notes.push(ce('li', {}, plural(b.visit, 'story is', 'stories are') + ' waiting for a page to be opened (a bot check or login). They have a button in the list.'));
      if (b.empty.length) notes.push(ce('li', {}, plural(b.empty.length, 'had', 'had') + ' no chapter list to read, so weren’t added (a forum thread needs Threadmarks): ' + b.empty.slice(0, 6).join(', ') + (b.empty.length > 6 ? ', and ' + (b.empty.length - 6) + ' more' : '') + '.'));
      b.failed.slice(0, 6).forEach(f => notes.push(ce('li', {}, f.title + ': ' + f.error)));
      if (b.failed.length > 6) notes.push(ce('li', {}, 'and ' + (b.failed.length - 6) + ' more that failed.'));
      $('imp-summary').replaceChildren(notes.length ? ce('ul', {}, ...notes) : '');
    }
    $('imp-stop').hidden = !(working && b.running); $('imp-resume').hidden = !(working && b.paused);
    $('imp-go').hidden = working || !imp.items.length;
    if (!working && imp.items.length) {
      const have = tracked(), fresh = imp.items.filter(i => !have.has(i.key)), keep = $('imp-list').scrollTop;
      $('imp-title').textContent = imp.label + ': ' + plural(imp.items.length, 'story', 'stories') + ' found' + (fresh.length < imp.items.length ? ' (' + (imp.items.length - fresh.length) + ' already tracked)' : '') + (imp.more ? ', more pages not read' : '');
      $('imp-list').replaceChildren(...imp.items.map(i => {
        const got = have.has(i.key), cb = ce('input', { type: 'checkbox', checked: !got && imp.sel.has(i.key), disabled: got, onchange: e => { if (e.target.checked) imp.sel.add(i.key); else imp.sel.delete(i.key); impCount(); } });
        return ce('li', {}, ce('label', { class: got ? 'have' : '' }, cb, ce('span', { class: 't', title: i.title }, i.title), ce('span', { class: 'by' }, got ? 'already tracked' : i.author)));
      }));
      $('imp-list').scrollTop = keep;
      impCount();
    }
  }
  function impCount() {                                                   // update the button and time estimate from the ticked items without redrawing the list
    const have = tracked(), n = [...imp.sel].filter(k => !have.has(k)).length;
    $('imp-go').textContent = n ? 'Import ' + plural(n, 'story', 'stories') : 'Import';
    $('imp-go').disabled = !n;
    $('imp-eta').textContent = n ? 'About ' + Math.max(1, Math.ceil(n * (S.settings.hostGapSec + 2) / 60)) + ' min. Each story is read once, with a pause between requests to the same site.' : '';
  }

  async function scan(url, seed, gesture) {
    let origin; try { origin = new URL(url).origin; if (!/^https?:/.test(origin)) throw new Error(); } catch (e) { impMsg('That isn’t a web address.', true); return; }
    const pat = { origins: [origin + '/*'] };
    const ok = gesture ? await api.permissions.request(pat).catch(() => false) : await api.permissions.contains(pat).catch(() => false);   // the permission request must run directly in the click handler
    if (!ok) { impMsg('Serial Tracker needs access to ' + new URL(url).host + ' to read that list and the stories on it. Only the list and stories you ask for are read; nothing is sent anywhere else.', true, ' ', ce('button', { class: 'btn', type: 'button', onclick: () => scan(url, seed, true) }, 'Allow access')); return; }
    if (gesture) await U.send({ type: 'accessChanged' });
    imp.scanning = true; imp.items = []; imp.sel = new Set(); renderImporter(); impMsg('Reading the list…');
    const r = await U.send({ type: 'scanList', url, seed }).catch(e => ({ ok: false, error: String(e) }));
    imp.scanning = false;
    if (!r || !r.ok) {
      renderImporter();
      const open = r && r.needsYou ? [' ', ce('button', { class: 'btn', type: 'button', onclick: () => api.tabs.create({ url }) }, 'Open the list'), ce('span', { class: 'muted' }, ' Then press the Serial Tracker button there and choose Import.')] : [];
      if (r && r.kind === 'permission') open.push(' ', ce('button', { class: 'btn', type: 'button', onclick: () => scan(url, seed, true) }, 'Allow access'));
      impMsg((r && r.error) || 'That didn’t work.', true, ...open); return;
    }
    Object.assign(imp, { items: r.items, label: r.label || 'List', more: r.more, listUrl: url, fromBookmarks: false, sel: new Set(r.curated ? r.items.map(i => i.key) : []) });
    renderImporter();
    impMsg(!r.items.length ? 'No stories found on that page. Is it the right list, and are you logged in on that site?'
      : r.partial || (!r.curated ? 'This isn’t a list you built yourself, so nothing is ticked: choose what you want.' : ''), !r.items.length || !!r.partial);
  }

  // ---- a Firefox bookmarks folder as the list. Only Royal Road stories and forum threads can be added this way (the same kinds as the site lists).
  const BM_ADAPTERS = ['xenforo', 'royalroad', 'scribblehub', 'patreon'], bmBtn = $('imp-bm-go'), bmSel = $('imp-bm-folder');
  let bmReady = false;
  async function bmLoadFolders() {
    const tree = await api.bookmarks.getTree(), out = [];
    const walk = (n, path, depth) => {
      if (n.url) return;
      const here = n.title ? path.concat(n.title) : path;
      if (n.title) out.push({ id: n.id, name: '\u00a0\u00a0'.repeat(Math.max(0, depth - 1)) + n.title, full: here.join(' › ') });
      (n.children || []).forEach(c => walk(c, here, n.title ? depth + 1 : depth));
    };
    tree.forEach(t => walk(t, [], 0));
    bmSel.replaceChildren(ce('option', { value: '' }, 'Choose a folder…'), ...out.map(f => ce('option', { value: f.id, 'data-full': f.full }, f.name)));
  }
  bmBtn.addEventListener('click', async () => {
    if (!bmReady) {
      const ok = await api.permissions.request({ permissions: ['bookmarks'] }).catch(() => false);      // the permission request must run directly in the click handler
      if (!ok) { impMsg(noAndroid('Reading bookmarks', U.permDeclined('bookmarks')), true); return; }
      try { await bmLoadFolders(); } catch (e) { impMsg('Couldn’t read your bookmarks.', true); return; }
      bmReady = true; bmSel.hidden = false; bmBtn.textContent = 'Read this folder'; impMsg('Pick a folder, then press Read this folder.'); return;
    }
    if (!bmSel.value) { impMsg('Pick a folder first.', true); return; }
    let nodes; try { nodes = await api.bookmarks.getSubTree(bmSel.value); } catch (e) { impMsg('Couldn’t read that folder.', true); return; }
    const AD = self.ST.adapters, items = [], keys = new Set(); let skipped = 0;
    const walk = n => {
      if (n.url) {
        const idn = /^https?:/.test(n.url) ? AD.identify(n.url) : null;
        if (!idn || !BM_ADAPTERS.includes(idn.adapter)) { skipped++; return; }
        if (keys.has(idn.key)) return;
        keys.add(idn.key); items.push({ url: idn.homeUrl, key: idn.key, adapter: idn.adapter, title: String(n.title || '').slice(0, 140) || idn.hint || idn.homeUrl, author: '' });
      }
      (n.children || []).forEach(walk);
    };
    nodes.forEach(walk);
    const opt = bmSel.selectedOptions[0], name = (opt && opt.dataset.full) || 'folder';
    Object.assign(imp, { items, label: 'Bookmarks › ' + name, more: false, listUrl: '', fromBookmarks: true, sel: new Set(items.map(i => i.key)) });
    renderImporter();
    impMsg(!items.length ? 'No Royal Road, Scribble Hub or forum stories were found in that folder.' + (skipped ? ' ' + plural(skipped, 'bookmark was', 'bookmarks were') + ' skipped.' : '')
      : skipped ? plural(skipped, 'bookmark was', 'bookmarks were') + ' skipped: not a Royal Road or Scribble Hub story, or a forum thread.' : '', !items.length);
  });

  function openImporter() { if (!idp.open) idp.showModal(); renderImporter(); }
  idp.querySelector('.dclose').addEventListener('click', () => idp.close());
  $('imp-sources').replaceChildren(...SOURCES.map(([label, url]) => ce('button', { class: 'chip', type: 'button', onclick: () => scan(url, null, true) }, label)));
  $('imp-scan').addEventListener('click', () => { const v = $('imp-url').value.trim(); if (v) scan(v, null, true); });
  $('imp-url').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); $('imp-scan').click(); } });
  $('imp-all').addEventListener('click', () => { const have = tracked(); imp.sel = new Set(imp.items.filter(i => !have.has(i.key)).map(i => i.key)); renderImporter(); });
  $('imp-none').addEventListener('click', () => { imp.sel = new Set(); renderImporter(); });
  $('imp-go').addEventListener('click', async () => {
    const have = tracked(), items = imp.items.filter(i => imp.sel.has(i.key) && !have.has(i.key));
    if (imp.fromBookmarks) {                                                // the permission request must run directly in the click handler. Sites that are already allowed resolve immediately.
      const origins = [...new Set(items.map(i => { try { return new URL(i.url).origin + '/*'; } catch (e) { return null; } }).filter(Boolean))];
      if (origins.length && !(await api.permissions.request({ origins }).catch(() => false))) { impMsg('Access to those sites was declined, so they can’t be read.', true); return; }
      await U.send({ type: 'accessChanged' });
    }
    const r = await act({ type: 'importBatch', items, favorite: $('imp-fav').checked, caughtUp: $('imp-caught').checked });
    if (r && r.ok) { const d = await U.loadData(); S.bulk = d.bulk; imp.items = []; renderImporter(); }
  });
  $('imp-stop').addEventListener('click', () => act({ type: 'bulkStop' }));
  $('imp-resume').addEventListener('click', () => act({ type: 'bulkResume' }));
  $('imp-close').addEventListener('click', async () => {
    if (S.bulk && !S.bulk.running && !S.bulk.paused) await U.send({ type: 'bulkClear' });      // a finished summary has been seen
    idp.close();
  });
  $('open-import').addEventListener('click', openImporter);
  idp.addEventListener('close', () => { if (S.bulk && !S.bulk.running && !S.bulk.paused && S.bulk.finishedAt) U.send({ type: 'bulkClear' }); });
  async function takeImportRequest() {                                    // the toolbar popup sent a list page it was showing
    const ir = (await api.storage.local.get('importRequest')).importRequest;
    if (!ir) return;
    await U.send({ type: 'importRequest', request: null });
    if (Date.now() - ir.at > 10 * MINUTE || !ir.request || typeof ir.request.url !== 'string') return;
    openImporter(); scan(ir.request.url, ir.request.seed, false);
  }

  // ---------------------------------------------------------------- live
  api.storage.onChanged.addListener(async ch => {
    if (ch && ch.importRequest && ch.importRequest.newValue) takeImportRequest();      // the dashboard was already open: the popup sent a list page
    const d = await U.loadData(); S.recs = d.recs; S.real = d.real; S.groups = d.groups; S.settings = d.settings; S.run = d.run; S.sched = d.sched; S.bulk = d.bulk; S.scan = d.scan;
    renderHeader(Date.now()); renderVisitLine(); renderPlaceNote(); renderSoon(); renderImporter();
    if (imp.scanning && S.scan && S.scan.running) impMsg('Reading the list… ' + plural(S.scan.pages || 0, 'page', 'pages') + ', ' + plural(S.scan.found || 0, 'story', 'stories') + ' so far.');
  });
  setInterval(() => { if (!document.hidden && !typing()) render(); }, 30000);                 // refresh the countdowns
  document.addEventListener('visibilitychange', () => { if (!document.hidden) reload(); });
  reload().then(() => { takeHash(); takeImportRequest(); });
})();
