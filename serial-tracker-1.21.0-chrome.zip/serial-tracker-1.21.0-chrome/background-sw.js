// Serial Tracker - Chrome background (service worker). Loads the same scripts Firefox lists under background.scripts, in the same order.
// Listeners are registered while these scripts run, as a service worker requires.
importScripts('lib/engine.js', 'lib/adapters.js', 'lib/model.js', 'lib/domops.js', 'background.js');
